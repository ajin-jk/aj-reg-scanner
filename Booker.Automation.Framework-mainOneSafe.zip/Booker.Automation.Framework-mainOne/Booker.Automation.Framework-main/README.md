# Booker.Automation.Framework
This repository contains all the sample and perquisite set-up for the Booker Automation Framework.
