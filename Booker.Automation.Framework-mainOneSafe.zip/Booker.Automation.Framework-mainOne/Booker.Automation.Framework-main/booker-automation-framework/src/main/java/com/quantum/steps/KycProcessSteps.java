package com.quantum.steps;

import com.qmetry.qaf.automation.step.QAFTestStep;
import com.quantum.utils.ReportUtils;

public class KycProcessSteps extends AbstractSteps {

    @QAFTestStep(description="I should able to see credit component on the my account page")
    public void iShouldAbleToSeeCreditComponentOnTheMyAccountPage(){
        ReportUtils.logAssert("verifying credit component present or not", creditComponentOnMyAccountPage.checkingCreditComponentOnMyAccountPage());
    }

    @QAFTestStep(description="I click on the Apply for credit button")
    public void iClickOnTheApplyForCreditButton(){
        creditComponentOnMyAccountPage.clickingOnApplyForCreditButton();

    }
    @QAFTestStep(description="I click on the start Credit application button on the T&C page")
    public void iClickOnTheStartCreditApplicationButtonOnTheTCPage(){
        tnCPage.startingKYCApplicationFromKYCForm();
    }
    //I am choosing "Council / Local Authority" from trading style dropdown
    @QAFTestStep(description="I should be able to select the Trading Style as {0}")
    public void iShouldBeAbleToSelectTheTradingStyleAs(String journey){
        kycFormPage.chooseTradingStyle(journey);
    }
    @QAFTestStep(description="I enter all mandatory fields available on the Business Information section")
    public void iAmEnteringAllMandatoryFieldsAvailableOnTheBusinessInformationSection(){
        kycFormPage.fillMandatoryFieldsAvailableOnTheBusinessInformationSection();
    }
    @QAFTestStep(description="I click on Council Name text box and Enter text")
    public void iClickOnCouncilNameTextBoxAndEnterText(){
        kycFormPage.enterCouncilNameField();
    }
    @QAFTestStep(description="I click on Business Trading Name text box and Enter text")
    public void iClickOnBusinessTradingNameTextBoxAndEnterText(){
        kycFormPage.enterBusinessTradingName();
    }
    @QAFTestStep(description="I click on the Postcode field and Enter text and number")
    public void iClickOnThePostcodeFieldAndEnterTextAndNumber(){
        kycFormPage.enterBusinessTradingAddressPostcode();
    }
    @QAFTestStep(description="I select an Registered Office Address from the dropdown list")
    public void iSelectAnRegisteredOfficeAddressFromTheDropdownlist(){
        kycFormPage.selectRegisteredOfficeAddress();
    }
    @QAFTestStep(description="I click on the VAT Registration Number text box and Enter text & number")
    public void iClickOnTheVATRegistrationNumberTextBoxAndEnterTextNumber(){
        kycFormPage.enterVATRegistrationNumber();
    }
    @QAFTestStep(description="I click on the Telephone Number field and Enter number")
    public void iClickOnTheTelephoneNumberFieldAndEnterNumber(){
        kycFormPage.enterTelephoneNumber();
    }
    @QAFTestStep(description="I click on the Email Address field and Enter text")
    public void iClickOnTheEmailAddressFieldAndEnterText(){
        kycFormPage.enterEmailAdd();
    }
    @QAFTestStep(description="I click on the Confirm Email Address field and Enter text")
    public void iClickOnTheConfirmEmailAddressFieldAndEnterText(){
        kycFormPage.enterConfirmEmail();
    }
    @QAFTestStep(description="I click on Date trading commenced selection box and Select a date from date picker")
    public void iClickOnDateTradingCommencedSelectionBoxAndSelectADateFromDatePicker(){
        kycFormPage.dateTradingCommenced();
    }
    @QAFTestStep(description="I click on Number of years at trading address text box and Enter number")
    public void iClickOnNumberOfYearsAtTradingAddressTextBoxAndEnterNumber(){
        kycFormPage.enterNumberOfYearsAtTheAddress();
    }
    @QAFTestStep(description="I click on Do you hold any other accounts with Booker dropdown box and select {0}")
    public void iClickOnDoYouHoldAnyOtherAccountsWithBookerDropdownBoxAndSelect(String Option){
        kycFormPage.choosingNoOtherAccountsWithBooker(Option);
    }

    @QAFTestStep(description="I click on Customer Account no one text box and Enter customer number")
    public void iClickOnCustomerAccountNoOneTextBoxAndEnterCustomerNumber() throws InterruptedException {
        kycFormPage.EnterCustomerAccountNo1();
    }
    @QAFTestStep(description="I click on Customer Account no two text box and Enter customer number")
    public void iClickOnCustomerAccountNoTwoTextBoxAndEnterCustomerNumber() throws InterruptedException {
        kycFormPage.EnterCustomerAccountNo2();
    }
    @QAFTestStep(description="I click on Customer Account no three text box and Enter customer number")
    public void iClickOnCustomerAccountNoThreeTextBoxAndEnterCustomerNumber() throws InterruptedException {
        kycFormPage.EnterCustomerAccountNo3();
    }
    @QAFTestStep(description="I click on Customer Account no four text box and Enter customer number")
    public void iClickOnCustomerAccountNoFourTextBoxAndEnterCustomerNumber() throws InterruptedException {
        kycFormPage.EnterCustomerAccountNo4();
    }
    @QAFTestStep(description="I click on Next Button to go to Proprietor Director Details section")
    public void iClickOnNextButtonToGoToProprietorDirectorDetailsSection(){
        kycFormPage.clickingOnNextButtonAvailableOnBusinessInformationSection();
    }
    @QAFTestStep(description="I enter all mandatory fields available on the Proprietor Details section")
    public void iAmEnteringAllMandatoryFieldsAvailableOnTheProprietorDetailsSection() throws InterruptedException {
        kycFormPage.fillingMandatoryFieldsAvailableOnTheProprietorDetailsSection();
    }
    @QAFTestStep(description="I click on Position dropdown box and select {0}")
    public void iClickOnPositionDropdownBoxAndSelect(String Position) throws InterruptedException {
        kycFormPage.selectingAPosition(Position);
    }

    @QAFTestStep(description="I click on Other details text box and Enter text")
    public void iClickOnOtherDetailsTextBoxAndEnterText(){
        kycFormPage.EnterOtherDetails();
    }
    @QAFTestStep(description="I click on First Name text box and Enter text")
    public void iClickOnFirstNameTextBoxAndEnterText(){
        kycFormPage.EnterFirstName();
    }
    @QAFTestStep(description="I click on Surname text box and Enter text")
    public void iClickOnSurnameTextBoxAndEnterText(){
        kycFormPage.EnterSurname();
    }
    @QAFTestStep(description="I click on Telephone Number text box and Enter number in Proprietor Director Section")
    public void iClickOnTelephoneNumberTextBoxAndEnterNumberInProprietorDirectorSection(){
        kycFormPage.EnterTelephoneNumberInProprietorSection();
    }
    @QAFTestStep(description="I click on Mobile Number text box and Enter number in Proprietor Director Section")
    public void iClickOnMobileNumberTextBoxAndEnterNumberInProprietorDirectorSection(){
        kycFormPage.EnterMobileNumberInProprietorSection();
    }
    @QAFTestStep(description="I click on Next Button to go to Credit Requirements Section")
    public void iClickOnNextButtonToGoToCreditRequirementsSection(){
        kycFormPage.clickingOnNextButtonAvailableOnTheProprietorDetailsSection();
    }

    @QAFTestStep(description="I enter all mandatory fields available on the Credit requirement section")
    public void iAmEnteringAllMandatoryFieldsAvailableOnTheCreditRequirementSection(){
        kycFormPage.fillingMandatoryFieldsAvailableOnTheCreditRequirementSection();
    }

    @QAFTestStep(description="I click on Average Weekly spend text box and Enter numbers")
    public void iClickOnAverageWeeklySpendTextBoxAndEnterNumbers(){
        kycFormPage.enteringAverageWeeklySpend();
    }

    @QAFTestStep(description="I click on Credit Limit Required spend text box and Enter numbers")
    public void iClickOnCreditLimitRequiredSpendTextBoxAndEnterNumbers(){
        kycFormPage.enteringCreditLimitRequired();
    }

    @QAFTestStep(description="I click on Credit Type dropdown box and select BACS option")
    public void iClickOnCreditTypeDropdownBoxAndSelectBACSOption(){
        kycFormPage.selectingCreditTye();
    }

    @QAFTestStep(description="I locate the submit button on KYC form page and checking whether it is clickable")
    public void iLocateTheSubmitButtonOnKYCFormPageAndCheckingWhetherItIsClickable(){
        kycFormPage.enterEmailAdd();
        ReportUtils.logAssert("Checking Submit button on KYC form", kycFormPage.checkingSubmitButtonIsClickable());
    }
    @QAFTestStep(description="I submit the KYC application")
    public void iAmSubmittingTheKYCApplication(){
        kycFormPage.clickingOnTheSubmitButton();
    }
    @QAFTestStep(description="I should able to navigate to the DocuSign page")
    public void iShouldAbleToNavigateToTheDocuSignPage(){
        ReportUtils.logAssert("verifying DocuSign page title", kycDocumentSignPage.checkingTitleOfTheDocuSignPage());

    }
    @QAFTestStep(description="I complete the DocuSign procedure")
    public void iCompleteTheDocuSignProcedure(){
        kycDocumentSignPage.completeDocumentSignSubmittingProcessForCouncilJourney();
    }

    @QAFTestStep(description="I decline the DocuSign document")
    public void iDeclineTheDocuSignProcedure(){
        kycDocumentSignPage.decliningTheDocumentSignProcess();
    }
    @QAFTestStep(description="I should navigate to the Stage completion page after signing the DocuSign process")
    public void iShouldNavigateToTheStageCompletionPageAfterSigningTheDocuSignProcess(){
        ReportUtils.logAssert("verifying Stage completion page after completed DocuSign process", kycStageCompletionPage.checkingTheStageCompletionPageAfterCompletingDocuSignProcess());
    }
    @QAFTestStep(description="I should navigate to the Stage completion page after declining the docuSign process")
    public void iShouldNavigateToTheStageCompletionPageAfterDecliningTheDocuSignProcess(){
        ReportUtils.logAssert("verifying Stage completion page after declining DocuSign", kycStageCompletionPage.checkingTheStageCompletionPageAfterDecliningTheDocuSignProcess());
    }
    @QAFTestStep(description="I click on the Back To My Account button available on stage completion page")
    public void iClickOnTheBackToMyAccountButtonAvailableOnStageCompletionPage(){
        kycStageCompletionPage.clickingOnBackToMyAccountButtonOnStageCompletionPage();
    }


}
