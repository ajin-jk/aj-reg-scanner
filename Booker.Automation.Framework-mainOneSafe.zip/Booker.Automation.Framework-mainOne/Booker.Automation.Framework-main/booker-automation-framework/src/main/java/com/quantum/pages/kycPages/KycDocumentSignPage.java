package com.quantum.pages.kycPages;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.PropertyUtil;
import org.openqa.selenium.NoSuchElementException;

public class KycDocumentSignPage extends WebDriverBaseTestPage<WebDriverTestPage> {
    PropertyUtil props = ConfigurationManager.getBundle();
    @Override
    protected void openPage(PageLocator pageLocator, Object... objects) {

    }
    //DocuSign page
    @FindBy(locator = "//*[@id='welcome']/div/h1/span")
    private QAFExtendedWebElement docuSignPageHeader;
    @FindBy(locator = "//*[@id='action-bar-consent-control']/div/div[2]/div[2]/label/span")
    private QAFExtendedWebElement iAgreeCheckbox;
    @FindBy(locator = "//*[@id='action-bar-btn-continue']")
    private QAFExtendedWebElement actionBarButtonContinue;
    @FindBy(locator = "//*[@id='navigate-btn']")
    private QAFExtendedWebElement navigationStartButton;
    @FindBy(locator = "//div[@class='tab-text' and text()='Sign']")
    private QAFExtendedWebElement signedOnBehalfOfTheCustomer;
    @FindBy(locator = "//*[@id='adopt-dialog']/div/div[3]/button[1]")
    private QAFExtendedWebElement adoptAndSignButtonOnModal;
    @FindBy(locator = "//*[@id='action-bar-btn-finish']")
    private QAFExtendedWebElement actionBarButtonFinish;
    @FindBy(locator = "//*[@id='otherActionsButton']")
    private QAFExtendedWebElement otherActionsMenu;
    @FindBy(locator = "//*[@id='otherActionsMenu']/div/ul/li[3]/button")
    private QAFExtendedWebElement declineOption;
    @FindBy(locator = "//*[@id='ModalContainer']/div[2]/div[2]/div/div/div[4]/button[1]")
    private QAFExtendedWebElement continueButtonOnCautionModalContainer;
    @FindBy(locator = "//*[@id='ModalContainer']/div[2]/div[2]/div/div/div[3]/div/div[3]/div/label/span/span")
    private QAFExtendedWebElement iWithdrawElectronicRecordsCheckbox;
    @FindBy(locator = "//*[@id='ModalContainer']/div[2]/div[2]/div/div/div[4]/button[1]")
    private QAFExtendedWebElement declineButtonOnDeclineToSignModal;

    public boolean checkingTitleOfTheDocuSignPage() {
        docuSignPageHeader.waitForVisible(5000);
        boolean checkingTitle = driver.getTitle().equals("Review and sign document(s) | Docusign");
        return checkingTitle;
    }
    public void completeDocumentSignSubmittingProcessForCouncilJourney() {
        try {
            iAgreeCheckbox.waitForVisible(1000);
            iAgreeCheckbox.click();
        } catch (NoSuchElementException e) {
            System.out.println(e + "Element Not Found");
        }
        actionBarButtonContinue.waitForEnabled(2000);
        actionBarButtonContinue.click();
        navigationStartButton.waitForVisible(1000);
        navigationStartButton.click();
        signedOnBehalfOfTheCustomer.waitForVisible(4000);
        signedOnBehalfOfTheCustomer.click();
        adoptAndSignButtonOnModal.waitForVisible(3000);
        adoptAndSignButtonOnModal.click();
        actionBarButtonFinish.waitForVisible(2000);
        actionBarButtonFinish.click();
    }

    public void decliningTheDocumentSignProcess(){
        try {
            iAgreeCheckbox.waitForVisible(1000);
            iAgreeCheckbox.click();
        }catch (NoSuchElementException e){
            System.out.println(e + "Element Not Found");
        }
        actionBarButtonContinue.waitForEnabled(2000);
        actionBarButtonContinue.click();
        otherActionsMenu.waitForVisible(1000);
        otherActionsMenu.click();
        declineOption.waitForVisible(2000);
        declineOption.click();
        continueButtonOnCautionModalContainer.waitForVisible(3000);
        continueButtonOnCautionModalContainer.click();
        iWithdrawElectronicRecordsCheckbox.waitForVisible(3000);
        iWithdrawElectronicRecordsCheckbox.click();
        declineButtonOnDeclineToSignModal.click();
    }

}
