package com.quantum.pages.registrationPages;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.PropertyUtil;
import org.openqa.selenium.support.ui.Select;

import static com.quantum.utils.CommonUtils.checkingBgColor;

public class CreateAnAccountPage extends WebDriverBaseTestPage<WebDriverTestPage> {

    PropertyUtil props = ConfigurationManager.getBundle();

    @Override
    protected void openPage(PageLocator locator, Object... args) {
    }

    @FindBy(locator = "create.account.page.header")
    QAFExtendedWebElement pageHeader;

    @FindBy(locator = "reg.acordian.about.you")
    QAFExtendedWebElement aboutYouTab;

    @FindBy(locator = "reg.form.about.you.title")
    QAFExtendedWebElement yourTitle;

    @FindBy(locator = "reg.form.about.you.first.name")
    QAFExtendedWebElement yourFirstName;

    @FindBy(locator = "reg.form.about.you.last.name")
    QAFExtendedWebElement yourLastName;

    @FindBy(locator = "reg.form.about.you.confirmEmail")
    QAFExtendedWebElement yourConfirmEmail;

    @FindBy(locator = "reg.form.about.you.mobNumber")
    QAFExtendedWebElement yourMobNumber;

    @FindBy(locator = "reg.form.about.you.legal.owner.yes")
    QAFExtendedWebElement yourLegalOwnerYes;

    @FindBy(locator = "reg.form.about.you.next.button")
    QAFExtendedWebElement yourNextButton;

    @FindBy(locator = "reg.form.about.you.email")
    QAFExtendedWebElement yourEmail;

    @FindBy(locator = "reg.form.your.business.tab")
    QAFExtendedWebElement yourBusinessModuleTab;

    @FindBy(locator = "reg.form.business.sector")
    QAFExtendedWebElement yourBusinessSector;

    @FindBy(locator = "reg.form.control.of.business.yes")
    QAFExtendedWebElement radioControlOfBusinessYes;

    @FindBy(locator = "reg.form.business.name")
    QAFExtendedWebElement yourBusinessName;

    @FindBy(locator = "reg.form.business.phone.number")
    QAFExtendedWebElement yourBusinessPhoneNumber;

    @FindBy(locator ="reg.form.business.postcode")
    QAFExtendedWebElement yourBusinessPostcode;

    @FindBy(locator = "reg.form.business.address.lookup")
    QAFExtendedWebElement yourBusinessAddressLookup;

    @FindBy(locator = "reg.form.business.select.address")
    QAFExtendedWebElement yourBusinessSelectAddress;

    @FindBy(locator = "reg.form.business.tobacco.track.trace.no")
    QAFExtendedWebElement radioTobaccoOptionNo;

    @FindBy(locator = "reg.form.business.tAndC")
    QAFExtendedWebElement regCheckBoxTAndC;

    @FindBy(locator = "reg.form.business.booker.pp")
    QAFExtendedWebElement regCheckBoxBookerPP;

    @FindBy(locator = "reg.form.business.next.button")
    QAFExtendedWebElement nextButtonOnBusinessModule;

    @FindBy(locator = "reg.form.your.branch.tab")
    QAFExtendedWebElement yourBranchModuleTab;

    @FindBy(locator = "reg.form.nearest.branch")
    QAFExtendedWebElement nearestBranchName;

    @FindBy(locator = "reg.form.select.branch.button.first.in.list")
    QAFExtendedWebElement selectBranchButtonOfFirstInTheList;

    @FindBy(locator = "reg.selected.branch.name")
    QAFExtendedWebElement selectedBranchName;

    @FindBy(locator = "reg.return.to.branch.results.button")
    QAFExtendedWebElement returnToBranchResultsButton;

    @FindBy(locator = "reg.recaptcha.iframe")
    QAFExtendedWebElement reCaptchaIframe;

    @FindBy(locator = "reg.recaptcha.checkbox.border")
    QAFExtendedWebElement checkBoxReCaptcha;

    @FindBy(locator = "reg.final.submit.button")
    QAFExtendedWebElement registrationSubmitButton;

    @FindBy(locator = "reg.confirmation.acceptance.icon")
    QAFExtendedWebElement confirmationImage;

    @FindBy(locator = "reg.form.iframe.your.branch")
    QAFExtendedWebElement iframeYourBranch;

    public String checkingCreateAnAccountPageLoaded(){
        pageHeader.waitForVisible(5000);
        String pageHeaderText = pageHeader.getText();
        return pageHeaderText;
    }

    public void fillingMandatoryFieldsOnAboutYouModule(){
        yourTitle.waitForVisible(2000);
        Select dropdownElement = new Select(yourTitle);
        dropdownElement.selectByVisibleText("Mr");
        yourFirstName.waitForVisible(1000);
        yourFirstName.sendKeys("James");
        yourLastName.waitForVisible(1000);
        yourLastName.sendKeys("Anderson");
        yourEmail.waitForVisible(1000);
        yourEmail.sendKeys("test@test.com");
        yourConfirmEmail.waitForVisible(1000);
        yourConfirmEmail.sendKeys("test@test.com");
        yourMobNumber.waitForVisible(1000);
        yourMobNumber.sendKeys("74987654321");
        yourLegalOwnerYes.click();
        //return yourLegalOwnerYes.isSelected();
    }

    public String clickingOnNextButtonOnAboutYouModule(){
        yourNextButton.waitForVisible(2000);
        yourNextButton.click();
        //String bgColor = checkingBgColor(aboutYouTab);
        //return bgColor;
        return checkingBgColor(aboutYouTab);
    }

    public String checkingBGColorAboutYouAlone(){
        return checkingBgColor(aboutYouTab);
    }

    public void checkingValueAppearedOnBusinessSector(String yourBusiness){
        System.out.println(checkingBgColor(yourBusinessModuleTab));

        yourBusinessSector.waitForVisible(1000);
        /**
        try {
            return yourBusinessSector.getText().equalsIgnoreCase(yourBusiness);
        }catch (Exception e) {
            return false;
        }
         **/
        System.out.println(yourBusinessSector.getText());
    }

    public void enteringMandatoryDetailsOnYourBusinessModule(){
        radioControlOfBusinessYes.click();
        yourBusinessName.sendKeys("AnyName");
        yourBusinessPhoneNumber.sendKeys("0123456789");
        yourBusinessPostcode.waitForVisible(1000);
        yourBusinessPostcode.sendKeys("NN81LT");
        yourBusinessAddressLookup.click();
        yourBusinessSelectAddress.waitForVisible(2000);
        Select selectAddressDropdown = new Select(yourBusinessSelectAddress);
        selectAddressDropdown.selectByIndex(2);
        radioTobaccoOptionNo.click();
        regCheckBoxTAndC.click();
        regCheckBoxBookerPP.click();
    }

    public void clickingOnNextButtonAvailableONBusinessModule(){
        nextButtonOnBusinessModule.click();
        System.out.println(checkingBgColor(yourBusinessModuleTab));
        System.out.println(checkingBgColor(yourBranchModuleTab));
    }

    public void checkingBranchResults(){
        driver.switchTo().frame(iframeYourBranch);
        System.out.println(nearestBranchName.getText());
    }

    public void selectingFirstBranchFromTheList(){
        selectBranchButtonOfFirstInTheList.waitForVisible(2000);
        selectBranchButtonOfFirstInTheList.click();
    }

    public void checkingSelectedBranchDetails(){
        System.out.println(selectedBranchName.getText());
        returnToBranchResultsButton.waitForVisible(3000);
        System.out.println(returnToBranchResultsButton.getText());
        driver.switchTo().defaultContent();
    }

    public void test() throws InterruptedException {
        driver.switchTo().frame(reCaptchaIframe);
        System.out.println("captcha before");
        checkBoxReCaptcha.waitForVisible(30000);

        checkBoxReCaptcha.click();
        System.out.println("captcha after");
        //wait(10000);
        driver.switchTo().defaultContent();
    }

    public void test1(){
        registrationSubmitButton.waitForVisible(2000);
        registrationSubmitButton.click();
    }

    public void test2(){
        boolean confirmationImagePresent = confirmationImage.isDisplayed();
        System.out.println("Image present" + confirmationImagePresent);
        boolean verifyAltValue = confirmationImage.getAttribute("alt").equalsIgnoreCase("Completed form - thank you");
        System.out.println("Same value as expected" + verifyAltValue);
    }


}
