package com.quantum.steps;

import com.qmetry.qaf.automation.step.QAFTestStep;
import com.quantum.utils.ReportUtils;

public class OrderConfirmationPageSteps extends AbstractSteps {

    @QAFTestStep(description="I should see order confirmation as {0} with order number")
    public void iShouldSeeOrderConfirmationAsWithOrderNumber(String message){
        ReportUtils.logAssert("verifying Order confirmation", orderConfirmationPage.getOrderConfirmationMessage().contains(message));
        ReportUtils.logAssert("verifying Order number generation", Integer.parseInt(orderConfirmationPage.getOrderNumber())>0);
    }

    @QAFTestStep(description="I should see order confirmation as {0} with order number and category details")
    public void iShouldSeeOrderConfirmationAsWithOrderNumberAndCategoryDetails(String message){
        ReportUtils.logAssert("verifying Order confirmation", orderConfirmationPage.getOrderConfirmationMessage().contains(message));
        ReportUtils.logAssert("verifying Order number with category type :" + orderConfirmationPage.getBRPOrderNumber() + ".", orderConfirmationPage.getBRPOrderNumber().trim().contains("Ambient"));
    }
    @QAFTestStep(description="I should see order confirmation as {0} and category detail {1}")
    public void iShouldSeeOrderConfirmationAsAndCategoryDetail(String message,String category){
        ReportUtils.logAssert("verifying Order confirmation", orderConfirmationPage.getOrderConfirmationMessage().contains(message));
        ReportUtils.logAssert("verifying Order number with category type :" + orderConfirmationPage.getBRPOrderNumber() + ".", orderConfirmationPage.getBRPOrderNumber().trim().contains(category));
    }

}
