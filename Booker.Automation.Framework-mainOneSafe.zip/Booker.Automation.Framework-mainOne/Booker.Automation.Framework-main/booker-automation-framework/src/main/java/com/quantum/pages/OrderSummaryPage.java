package com.quantum.pages;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.PropertyUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;

import java.util.List;


public class OrderSummaryPage extends WebDriverBaseTestPage<WebDriverTestPage> {
    @Override
    protected void openPage(PageLocator locator, Object... args) {
    }
    PropertyUtil props = ConfigurationManager.getBundle();

    @FindBy(locator = ".radio-input:nth-child(1) > .checkmark:nth-child(2)")
    private QAFExtendedWebElement payByCardOption;

    @FindBy(locator = ".d-flex .radio-input .checkmark")
    private QAFExtendedWebElement singleRadioPayByCardOption;
    @FindBy(locator = "#paymentOptionsButton")
    private QAFExtendedWebElement paymentOptionsButton;

    //This function will cover, if the selected account has only pay by card option e.g. : 889000000
    public void selectPayByCardOption(){
        List<WebElement> paymentOptions = driver.findElements(By.cssSelector(".d-flex .radio-input"));
        if (paymentOptions.size() > 1) {
            try {
                if (!payByCardOption.isSelected()) {
                    payByCardOption.click();
                }
            } catch (TimeoutException e) {
                System.out.println("Pay By Card option not found: " + e.getMessage());
            }
        } else {
            System.out.println("Only one payment option available, skipping Pay by Card selection.");
        }
        //clickPaymentOptionsButton();
    }

    public void clickPaymentOptionsButton(){
        paymentOptionsButton.waitForVisible(5000);
        paymentOptionsButton.click();
    }
}
