package com.quantum.pages.kycPages;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.PropertyUtil;
import org.openqa.selenium.JavascriptExecutor;

public class TnCPage extends WebDriverBaseTestPage<WebDriverTestPage> {
    PropertyUtil props = ConfigurationManager.getBundle();

    @Override
    protected void openPage(PageLocator pageLocator, Object... objects) {

    }

    @FindBy(locator = "//*[@id='booker_1termsconditions']/form/div[1]/div[2]/div[2]/div/div/label")
    private QAFExtendedWebElement checkBoxPrivacyPolicy;

    @FindBy(locator = "//*[@id='booker_1termsconditions']/form/div[1]/div[2]/div[3]/div/div/label")
    private QAFExtendedWebElement checkBoxOver18;
    @org.openqa.selenium.support.FindBy(css = "button#startApp")
    private QAFExtendedWebElement buttonStartCreditApplication;

    public void startingKYCApplicationFromKYCForm() {
        //to perform Scroll on application using Selenium
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,450)", "");

        //To enable the Start credit application, we need to select both checkboxes
        checkBoxPrivacyPolicy.click();
        checkBoxOver18.click();
        buttonStartCreditApplication.click();

    }


}
