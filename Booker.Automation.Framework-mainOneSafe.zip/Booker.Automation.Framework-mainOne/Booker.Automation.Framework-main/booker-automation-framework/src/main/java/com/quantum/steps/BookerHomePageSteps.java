package com.quantum.steps;

import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.quantum.utils.ReportUtils;
//import org.openqa.selenium.Cookie;

@QAFTestStepProvider
public class BookerHomePageSteps extends AbstractSteps {

	@QAFTestStep(description="I am on Booker Home Page")
	public void iAmOnBookerHomePage(){
		new WebDriverTestBase().getDriver().get(props.getString("env.baseurl"));
		bookerHomePage.allowCookies();

	}

	@QAFTestStep(description="I enter customer number as {0}")
	public void iEnterCustomerNumberAs(String customerNumber){
		bookerHomePage.enterCustomerNumber(customerNumber);
	}

	@QAFTestStep(description="I click on Login")
	public void iClickOnLogin(){
		bookerHomePage.clickLogin();
	}

	@QAFTestStep(description="I should see a warning message as {0}")
	public void iShouldSeeAWarningMessageAs(String message){
		String actualMessage = bookerHomePage.getCustomerValidationMessage();
		ReportUtils.logAssert("Validating customer number validation for invalid customer number", message.equalsIgnoreCase(actualMessage));
	}
	
	@QAFTestStep(description="I click on login button without entering any customer number")
	public void iClickOnLoginButtonWithoutEnteringAnyCustomerNumber(){
		bookerHomePage.clearCustomerNumber();
		bookerHomePage.clickLogin();
	}
	
	@QAFTestStep(description="I should see a red alert banner as {0}")
	public void iShouldSeeARedAlertBannerAs(String message){
		String actualMessage = bookerHomePage.getCustomerValidationMessage();
		ReportUtils.logAssert("Validating customer number validation for incorrect customer number", message.equalsIgnoreCase(actualMessage));
	}
	
	@QAFTestStep(description="I should see customer number field exists")
	public void iShouldSeeCustomerNumberFieldExists(){
		ReportUtils.logAssert("Customer number field does not exist",bookerHomePage.isCustomerFieldExists());
	}

    @QAFTestStep(description="I should be redirected to Booker Home Page")
    public void iShouldBeRedirectedToBookerHomePage(){
		ReportUtils.logAssert("verifying user redirected to Booker Home Page",bookerHomePage.isHomePageLogoDisplayed());
    }

	@QAFTestStep(description="I click on register button")
	public void iClickOnRegisterButton(){
		bookerHomePage.clickRegisterButton();
	}


}
