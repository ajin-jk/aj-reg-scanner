package com.quantum.steps;

import com.qmetry.qaf.automation.step.QAFTestStep;

public class OrderSummaryPageSteps extends AbstractSteps {

    @QAFTestStep(description="I select pay by card option on order summary page and proceed")
    public void iSelectPayByCardOptionOnOrderSummaryPageAndProceed(){
        orderSummaryPage.selectPayByCardOption();
        orderSummaryPage.clickPaymentOptionsButton();
    }

    @QAFTestStep(description="I click on Green button payment Options on order summary page")
    public void iClickOnGreenButtonPaymentOptionsOnOrderSummaryPage(){
        orderSummaryPage.clickPaymentOptionsButton();
    }

}
