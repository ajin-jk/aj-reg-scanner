package com.quantum.pages.kycPages;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.PropertyUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class KycFormPage extends WebDriverBaseTestPage<WebDriverTestPage> {

    PropertyUtil props = ConfigurationManager.getBundle();

    @Override
    protected void openPage(PageLocator locator, Object... args) {
    }

    Duration sd = Duration.ofSeconds(20);
    WebDriverWait wait = new WebDriverWait(driver, sd);

    @FindBy(locator = "//kyc-input[@data-type='select' and @data-label='Trading style']")
    private QAFExtendedWebElement tradingStyle;
    @FindBy(locator = "//kyc-input[@data-type='text' and @data-label='Council Name']")
    private QAFExtendedWebElement councilNAme;

    public void chooseTradingStyle(String journey) {
        // Wait until the shadow host element is available
        WebElement shadowHost = wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("kyc-input[data-type='select']")));
        SearchContext shadowRoot = (SearchContext ) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowHost);
        // Now locate the <select> element inside the shadow DOM
        WebElement selectElement = shadowRoot.findElement(By.cssSelector("select"));
        wait.until(ExpectedConditions.elementToBeClickable(selectElement));
        selectElement.click();

        List<WebElement> options = selectElement.findElements(By.tagName("option"));
        for (WebElement option : options) {
            if (option.getText().equals(journey)) {
                option.click();
                break;  // Break out of the loop once the option is selected
            }
        }
    }
    //Business Information Section ----------------
    public void fillMandatoryFieldsAvailableOnTheBusinessInformationSection() {
        enterCouncilNameField();
        selectRegisteredOfficeAddress();
        enterTelephoneNumber();
        enterEmailAdd();
        enterConfirmEmail();
        dateTradingCommenced();
        enterNumberOfYearsAtTheAddress();
        choosingNoOtherAccountsWithBooker("No");
        clickingOnNextButtonAvailableOnBusinessInformationSection();
    }
    public void enterCouncilNameField(){
        SearchContext shadowConcil = driver.findElement(By.xpath("//kyc-input[@data-type='text' and @data-label='Council Name']")).getShadowRoot();
        WebElement councilNameField = shadowConcil.findElement(By.cssSelector("input[type='text'][minlength='2'][maxlength='40']"));
        councilNameField.clear();
        councilNameField.sendKeys("CouncilTest");
    }
    public void enterBusinessTradingName() {
        SearchContext shadowBusinessName = driver.findElement(By.xpath("//kyc-input[@data-type='address' and @data-request-field-name='businesss-trading-name']")).getShadowRoot();
        WebElement businessTradingName = shadowBusinessName.findElement(By.cssSelector("input[type='text'][minlength='2'][maxlength='40']"));
        businessTradingName.clear();
        businessTradingName.sendKeys("Business Test");
    }
    public void selectRegisteredOfficeAddress(){
        SearchContext shadowRegOfficePostcode = driver.findElement(By.xpath("/html/body/main/div/div/kyc-accordion/accordion-tab[1]/tab-content/div/address-box[2]")).getShadowRoot();
        WebElement postcodeInput = shadowRegOfficePostcode.findElement(By.cssSelector("input[name='postcode']"));
        postcodeInput.clear();
        postcodeInput.sendKeys("NN3 3HH");

        WebElement addressLookup = shadowRegOfficePostcode.findElement(By.cssSelector("button.address-lookup-btn"));
        addressLookup.click();

        WebElement selectAddress = shadowRegOfficePostcode.findElement(By.cssSelector("select[name='addressSelect']"));
        wait.until(ExpectedConditions.elementToBeClickable(selectAddress));
        Select select = new Select(selectAddress);
        select.selectByIndex(3);
    }
    //This is for my reference, below steps also will work - Commented by Ajin
//        WebElement selectAddress = shadowRegOfficePostcode.findElement(By.cssSelector("select[name='addressSelect']"));
//        wait.until(ExpectedConditions.elementToBeClickable(selectAddress));
//        selectAddress.click();
//        List<WebElement> options = selectAddress.findElements(By.tagName("option"));
//        System.out.println(options.get(2).getText());
//        WebElement addressSelectedOption = options.get(2);
//        addressSelectedOption.click();
    public void enterBusinessTradingAddressPostcode() {
        SearchContext shadowCouncil = driver.findElement(By.xpath("//address-box[@data-id='trading-address']")).getShadowRoot();
        shadowCouncil.findElement(By.cssSelector("input[type='text'][minlength='6'][maxlength='8']")).sendKeys("NhhN3 3HH");
    }
    public void enterVATRegistrationNumber() {
        SearchContext shadowCouncil = driver.findElement(By.xpath("//kyc-input[@data-type='numeric-text' and @data-request-field-name='vat-registration-number']")).getShadowRoot();
        shadowCouncil.findElement(By.cssSelector("input[type='text'][minlength='2'][maxlength='20']")).sendKeys("GB123456789");
    }
    public void enterTelephoneNumber(){
        SearchContext shadowRegCharityNumber = driver.findElement(By.cssSelector("kyc-input[data-name='TelephoneNumber']")).getShadowRoot();
        WebElement regCharityNumberInputBox = shadowRegCharityNumber.findElement(By.cssSelector("div > input[type=tel]"));
        regCharityNumberInputBox.clear();
        regCharityNumberInputBox.sendKeys("0123456789");
    }

    public void enterEmailAdd(){
        SearchContext shadowEmail = driver.findElement(By.cssSelector("kyc-input[id='user-email']")).getShadowRoot();
        WebElement emailAdd = shadowEmail.findElement(By.cssSelector("input[type='email']"));
        emailAdd.clear();
        emailAdd.sendKeys("test@test.com");
    }

    public void enterConfirmEmail(){
        SearchContext shadowConfirmEmail = driver.findElement(By.cssSelector("kyc-input[data-name='ConfirmEmailAddress']")).getShadowRoot();
        WebElement emailConfirmAdd = shadowConfirmEmail.findElement(By.cssSelector("input[type='email']"));
        emailConfirmAdd.clear();
        emailConfirmAdd.sendKeys("test@test.com");
    }

    public void dateTradingCommenced(){
        SearchContext shadowDateTradingCommenced = driver.findElement(By.cssSelector("kyc-input[data-name='DateTradingCommenced']")).getShadowRoot();
        WebElement dateTradingCommenced = shadowDateTradingCommenced.findElement(By.cssSelector("input[type='date']"));
        dateTradingCommenced.sendKeys("05/06/2024");
    }

    public void enterNumberOfYearsAtTheAddress(){
        SearchContext shadowDateTradingCommenced = driver.findElement(By.cssSelector("kyc-input[data-name='NumberOfYearsAtTradingAddress']")).getShadowRoot();
        WebElement dateTradingCommenced = shadowDateTradingCommenced.findElement(By.cssSelector("input[type='text']"));
        dateTradingCommenced.sendKeys("5");
    }

    public void choosingNoOtherAccountsWithBooker(String Option){
        int optionOrder;
        if (Option.equals("Yes")){
            optionOrder=1;
        }         else {
            optionOrder=2;
        }
        SearchContext shadowBookerAccountDropdown = driver.findElement(By.cssSelector("kyc-input[data-name='DoYouHoldAnyOtherAccountsWithBooker']")).getShadowRoot();
        WebElement selectOption = shadowBookerAccountDropdown.findElement(By.cssSelector("select"));
        Select select = new Select(selectOption);
        select.selectByIndex(optionOrder);
    }
    public void EnterCustomerAccountNo1() throws InterruptedException {
        SearchContext shadowCouncil = driver.findElement(By.xpath("//kyc-input[@data-type='numeric' and @data-request-field-name='customer-account-1']")).getShadowRoot();
        WebElement BookerCustomerOne = shadowCouncil.findElement(By.cssSelector("input[type='text'][minlength='0'][maxlength='9']"));
        BookerCustomerOne.sendKeys("705622851");
        Thread.sleep(1000);
    }

    public void EnterCustomerAccountNo2() throws InterruptedException {
        SearchContext shadowCouncil = driver.findElement(By.xpath("//kyc-input[@data-type='numeric' and @data-request-field-name='customer-account-2']")).getShadowRoot();
        shadowCouncil.findElement(By.cssSelector("input[type='text'][minlength='0'][maxlength='9']")).sendKeys("705622852");
        Thread.sleep(1000);
    }

    public void EnterCustomerAccountNo3() throws InterruptedException {
        SearchContext shadowCouncil = driver.findElement(By.xpath("//kyc-input[@data-type='numeric' and @data-request-field-name='customer-account-3']")).getShadowRoot();
        shadowCouncil.findElement(By.cssSelector("input[type='text'][minlength='0'][maxlength='9']")).sendKeys("705622853");
        Thread.sleep(1000);
    }

    public void EnterCustomerAccountNo4() throws InterruptedException {
        SearchContext shadowCouncil = driver.findElement(By.xpath("//kyc-input[@data-type='numeric' and @data-request-field-name='customer-account-4']")).getShadowRoot();
        shadowCouncil.findElement(By.cssSelector("input[type='text'][minlength='0'][maxlength='9']")).sendKeys("705622854");
        Thread.sleep(1000);
    }


    public void clickingOnNextButtonAvailableOnBusinessInformationSection(){
        SearchContext shadowNextBtn = driver.findElement(By.cssSelector("next-button[data-tab='0']")).getShadowRoot();
        shadowNextBtn.findElement(By.cssSelector("button.next-button")).click();
    }
    //Proprietor Details Section -----------------
    public void fillingMandatoryFieldsAvailableOnTheProprietorDetailsSection() throws InterruptedException {
        selectingAPosition("Owner");
        clickingOnNextButtonAvailableOnTheProprietorDetailsSection();
    }
    public void selectingAPosition(String Position) throws InterruptedException {
        int optionOrder = 0;
        if (Position.equals("Owner")){
            optionOrder=1;
        } else if(Position.equals("Partner")){
            optionOrder=2;
        } else if (Position.equals("Director")){
            optionOrder=3;
        } else if (Position.equals("Trustee")) {
            optionOrder = 4;
        } else if (Position.equals("Other")) {
            optionOrder = 5;
        }
        SearchContext shadowPosition = driver.findElement(By.cssSelector("kyc-input[id='position-field']")).getShadowRoot();
        WebElement selectOption = shadowPosition.findElement(By.cssSelector("select"));
        Select select = new Select(selectOption);
        select.selectByIndex(optionOrder);
        Thread.sleep(2000);
    }
    public void EnterOtherDetails() {
        SearchContext shadowCouncil = driver.findElement(By.xpath("//kyc-input[@data-type='text' and @data-request-field-name='position-other-details']")).getShadowRoot();
        shadowCouncil.findElement(By.cssSelector("input[type='text'][minlength='2'][maxlength='50']")).sendKeys("Some Other");
    }

    public void EnterFirstName() {
        SearchContext shadowCouncil = driver.findElement(By.xpath("//kyc-input[@data-type='text' and @data-request-field-name='first-name']")).getShadowRoot();
        shadowCouncil.findElement(By.cssSelector("input[type='text'][minlength='2'][maxlength='20']")).sendKeys("PK");
    }

    public void EnterSurname() {
        SearchContext shadowCouncil = driver.findElement(By.xpath("//kyc-input[@data-type='text' and @data-request-field-name='surname']")).getShadowRoot();
        shadowCouncil.findElement(By.cssSelector("input[type='text'][minlength='2'][maxlength='20']")).sendKeys("Lal");
    }

    public void EnterTelephoneNumberInProprietorSection() {
        SearchContext shadowCouncil = driver.findElement(By.xpath("//kyc-input[@data-type='phone' and @data-request-field-name='proprietor-telephone-number']")).getShadowRoot();
        shadowCouncil.findElement(By.cssSelector("input[type='tel'][minlength='10'][maxlength='20']")).sendKeys("01908555555");
    }

    public void EnterMobileNumberInProprietorSection() {
        SearchContext shadowCouncil = driver.findElement(By.xpath("//kyc-input[@data-type='phone' and @data-request-field-name='proprietor-mobile-number']")).getShadowRoot();
        shadowCouncil.findElement(By.cssSelector("input[type='tel'][minlength='10'][maxlength='20']")).sendKeys("0745656666");
    }

    public void clickingOnNextButtonAvailableOnTheProprietorDetailsSection(){
        SearchContext shadowNextBtn = driver.findElement(By.cssSelector("next-button[data-tab='1']")).getShadowRoot();
        shadowNextBtn.findElement(By.cssSelector("button.next-button")).click();
    }
    //Credit Requirement Section -----------------
    public void fillingMandatoryFieldsAvailableOnTheCreditRequirementSection() {
        enteringAverageWeeklySpend();
        enteringCreditLimitRequired();
        selectingCreditTye();
    }
    public void enteringAverageWeeklySpend() {
        SearchContext shadowAvgWeeklySpend = driver.findElement(By.cssSelector("kyc-input[data-name='AverageWeeklySpend']")).getShadowRoot();
        shadowAvgWeeklySpend.findElement(By.cssSelector("input[type='text']")).sendKeys("1500");
    }
    public void enteringCreditLimitRequired() {
        SearchContext shadowCreditLimitRequired = driver.findElement(By.cssSelector("kyc-input[data-name='CreditLimitRequired']")).getShadowRoot();
        shadowCreditLimitRequired.findElement(By.cssSelector("input[type='text']")).sendKeys("6500");
    }
    public void selectingCreditTye() {
        SearchContext shadowCreditType = driver.findElement(By.cssSelector("kyc-input[data-name='CreditType']")).getShadowRoot();
        WebElement selectOption = shadowCreditType.findElement(By.cssSelector("select"));
        Select select = new Select(selectOption);
        select.selectByIndex(1);
    }
    //Final KYC form Submission
    public void clickingOnTheSubmitButton() {
        SearchContext shadowFinalSubmit = driver.findElement(By.xpath("//*[@id='kyc-application-form']/next-button")).getShadowRoot();
        shadowFinalSubmit.findElement(By.cssSelector("button.next-button.submit")).click();
    }
    public boolean checkingSubmitButtonIsClickable() {
        SearchContext shadowFinalSubmit = driver.findElement(By.xpath("//*[@id='kyc-application-form']/next-button")).getShadowRoot();
        return shadowFinalSubmit.findElement(By.cssSelector("button.next-button.submit")).isDisplayed();
    }


}
