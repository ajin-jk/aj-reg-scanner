package com.quantum.pages.ScannerPages;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.PropertyUtil;
import com.quantum.utils.ReportUtils;

import java.util.HashMap;
import java.util.Map;

public class ScannerValidateBarcodePage extends WebDriverBaseTestPage<WebDriverTestPage> {

    @Override
    protected void openPage(PageLocator locator, Object... args){
    }
    PropertyUtil props = ConfigurationManager.getBundle();

    @FindBy(locator = "important.information.header")
    QAFExtendedWebElement headerImportantInformation;

    @FindBy(locator = "continue.button.important.information.page")
    QAFExtendedWebElement continueButtonOnInformationPage;

    @FindBy(locator = "successful.message.scanner.validation.page")
    QAFExtendedWebElement successfulMessageOnValidationPage;

    @FindBy(locator = "okButton.onScanner.Success.page")
    QAFExtendedWebElement okButtonOnScannerValidationPage;

    @FindBy(locator = "code.onBrowseScannedProductsPage")
    QAFExtendedWebElement productCodeOnBrowseScannedProductsPage;

    @FindBy(locator = "desc.onBrowseScannedProductsPage")
    QAFExtendedWebElement productDescOnBrowseScannedProductsPage;

    @FindBy(locator = "green.button.addAllToTrolley")
    QAFExtendedWebElement addAllToTrolleyGreenButton;


    public void clickingOnContinueButtonOnImportantInformationPage() {
        try {
            System.out.println(headerImportantInformation.getText());
            continueButtonOnInformationPage.click();
        } catch (Exception e){
            System.out.println("Important Information page skipped" + e);
        }
    }

    public String verifyTheSuccessfulMessage() {
        return successfulMessageOnValidationPage.getText();
    }

    public void clickOnOKButton() {
        okButtonOnScannerValidationPage.click();
    }

    public Map<String, String> checkingProductDetailsOnBrowseScannedProductsPage() {
        Map<String, String> productDetailsFromScannerUpload = new HashMap<String, String>();
        productCodeOnBrowseScannedProductsPage.waitForVisible(30000);
        productDetailsFromScannerUpload.put("description", productDescOnBrowseScannedProductsPage.getText());
        productDetailsFromScannerUpload.put("code", productCodeOnBrowseScannedProductsPage.getText());
        return productDetailsFromScannerUpload;
    }

    public void addingItemsIntoDeliveryTrolley()  {
        addAllToTrolleyGreenButton.click();
    }



}
