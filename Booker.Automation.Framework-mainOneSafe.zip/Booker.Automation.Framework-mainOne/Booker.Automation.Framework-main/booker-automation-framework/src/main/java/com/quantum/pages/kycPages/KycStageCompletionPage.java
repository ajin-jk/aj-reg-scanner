package com.quantum.pages.kycPages;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;

public class KycStageCompletionPage extends WebDriverBaseTestPage<WebDriverTestPage> {
    @Override
    protected void openPage(PageLocator pageLocator, Object... objects) {

    }
    @FindBy(locator = "//a[text()='Back to My Account']")
    private QAFExtendedWebElement backToMyAccountButton;

    public void clickingOnBackToMyAccountButtonOnStageCompletionPage(){
        backToMyAccountButton.click();
    }

    public boolean checkingTheStageCompletionPageAfterCompletingDocuSignProcess() {
        backToMyAccountButton.waitForVisible(10000);
        return driver.getCurrentUrl().equals("https://www.bookertest.co.uk/account/credit/application-complete");
    }

    public boolean checkingTheStageCompletionPageAfterDecliningTheDocuSignProcess() {
        backToMyAccountButton.waitForVisible(10000);
        return driver.getCurrentUrl().equals("https://www.bookertest.co.uk/account/credit/credit-application-redirect?status=decline");
    }

}
