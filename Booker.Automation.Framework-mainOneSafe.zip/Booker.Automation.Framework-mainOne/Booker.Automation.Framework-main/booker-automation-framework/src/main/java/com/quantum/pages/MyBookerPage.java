package com.quantum.pages;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.PropertyUtil;
import com.quantum.utils.DeviceUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.util.*;

public class MyBookerPage extends WebDriverBaseTestPage<WebDriverTestPage> {
    @Override
    protected void openPage(PageLocator locator, Object... args) {
    }
    PropertyUtil props = ConfigurationManager.getBundle();

    @FindBy(locator = ".top-nav .row")
    private QAFExtendedWebElement myAccountContainer;
    @FindBy(locator = "my-booker.clickAndCollect.button")
    private QAFExtendedWebElement clickAndCollectButton;

	@FindBy(locator = "my-booker.delivery.button")
	private QAFExtendedWebElement deliveryButton;

    @FindBy(locator = "my-booker.trolley.button")
    private QAFExtendedWebElement trolleyButton;

    @FindBy(locator = ".input-group > #search-input > .suggestion-keywords")
    private QAFExtendedWebElement searchProductTextBox;

    @FindBy(locator = "#search-input > div.input-group-append.search-button > button")
    private QAFExtendedWebElement searchProductButton;

    @FindBy(locator = "my-booker.myAccount.Link")
    private QAFExtendedWebElement myAccountLink;

    @FindBy(locator = "my-Booker.orderingTools.header")
    private QAFExtendedWebElement orderingToolsHeader;

    @FindBy(locator = "my-booker.orderingTools.sub.Scanner")
    private QAFExtendedWebElement subMenuScanner;

    public static String listOfProductsFromSearchCss="div.rowMode > div.p-0.p-sm-0.product-list.rowUnGrouped > div";

	public String getBackGroundColour(String option) {
        String bgcolor="";
        if(option.equalsIgnoreCase("delivery")){
            bgcolor = deliveryButton.getAttribute("class");
        } else  {
            clickClickAndCollectButton();
            bgcolor = clickAndCollectButton.getAttribute("class");
        }
        return bgcolor;
    }

    public void clickTrolleyButton(){
        trolleyButton.waitForVisible(20000);
        trolleyButton.click();
    }

    public void clickMyAccountLink(){
        //myAccountLink.waitForVisible(20000);
        //myAccountLink.click();
        myAccountContainer.waitForVisible(10000);
        myAccountContainer.findElement(By.linkText("My Account")).click();
    }

    public void clickClickAndCollectButton(){
        clickAndCollectButton.waitForVisible(5000);
        clickAndCollectButton.click();
    }

    public void searchForProduct(String productCode) {
        searchProductTextBox.waitForVisible(30000);
        searchProductTextBox.click();
        searchProductTextBox.sendKeys(productCode);
        searchProductButton.click();
    }

    public Map<String,String> getProductDetails(String productCodeExpected) throws InterruptedException {
        Map<String ,String> productDetails = new HashMap<String,String>();
        Thread.sleep(10000);
        List<WebElement> listOfProductsFromSearch = driver.findElements(By.cssSelector(listOfProductsFromSearchCss));
        for (WebElement product : listOfProductsFromSearch) {
            String productCode = product.findElement(By.cssSelector("div.product-number>span")).getText();
            if (productCode.contains(productCodeExpected)) {
                String productDescription = product.findElement(By.cssSelector("div.product-name-priceMarked > p.product-name")).getText();
                String productWeight = product.findElement(By.cssSelector("div.case-image>p")).getText();
                String productPrice="0";
                String productQuantitySelected="0";
                try {
                    productPrice = product.findElement(By.cssSelector("div.buy-this-product.product-counter > div.prices-and-taxes > div.price")).getText();
                    productQuantitySelected = product.findElement(By.cssSelector("div.buy-this-product.product-counter >div.shop.text-center>div>input")).getAttribute("value");
                }catch (Exception e){}
                productDetails.put("description", productDescription);
                productDetails.put("weight", productWeight);
                productDetails.put("price", productPrice);
                productDetails.put("quantity", productQuantitySelected);
                productDetails.put("code", productCode);
                break;
            }
        }
        return productDetails;
    }

    public void selectProductFromSearchResults(String productCodeExpected){
        List<WebElement> listOfProductsFromSearch = driver.findElements(By.cssSelector(listOfProductsFromSearchCss));
        for (WebElement product : listOfProductsFromSearch) {
            String productCode = product.findElement(By.cssSelector("div.product-number>span")).getText();
            if (productCode.contains(productCodeExpected)) {
                product.findElement(By.cssSelector("div.product-name-priceMarked > p.product-name")).click();
                break;
            }
        }
    }

    public void selectingScannerOptionFromOrderingToolsUsingMouseHover(){
        orderingToolsHeader.waitForVisible(1000);
        Actions actions = new Actions(driver);

        System.out.println(orderingToolsHeader.getText());

        actions.moveToElement(orderingToolsHeader).perform();
        subMenuScanner.waitForVisible(10000);
        System.out.println(subMenuScanner.getText());
        actions.moveToElement(subMenuScanner).perform();
        actions.click(subMenuScanner).build().perform();
       // subMenuScanner.click();

    }


}
