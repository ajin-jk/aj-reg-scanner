package com.quantum.steps;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.util.PropertyUtil;
import com.quantum.pages.*;
import com.quantum.pages.ScannerPages.*;
import com.quantum.pages.kycPages.*;
import com.quantum.pages.registrationPages.CreateAnAccountPage;
import com.quantum.pages.registrationPages.WhatIsYourBusinessPage;

import java.util.Map;

public class AbstractSteps {
	PropertyUtil props = ConfigurationManager.getBundle();
	public static Map<String,String> productDetailsList;

	LoginPage loginPage;
	 BookerHomePage bookerHomePage;
	 BookerHelpPage bookerHelpPage;

	 MyBookerPage myBookerPage;

	 TrolleyPage trolleyPage;
	 ProductDetailsPage productDetailsPage;
	 AdditionalInformationPage additionalInformationPage;
	 OrderSummaryPage orderSummaryPage;
	 PaymentPage paymentPage;
	 OrderConfirmationPage orderConfirmationPage;
	 WhatIsYourBusinessPage whatIsYourBusinessPage;
	CreateAnAccountPage createAnAccountPage;
	ChooseYourScannerPage chooseYourScannerPage;
	UploadsCS3000Page uploadsCS3000Page;
	ScannerValidateBarcodePage scannerValidateBarcodePage;
	KycFormPage kycFormPage;
	CreditComponentOnMyAccountPage creditComponentOnMyAccountPage;
	TnCPage tnCPage;
	KycDocumentSignPage kycDocumentSignPage;
	KycStageCompletionPage kycStageCompletionPage;

	 
	 public AbstractSteps() {
		 loginPage = new LoginPage();
		 bookerHomePage = new BookerHomePage();
		 bookerHelpPage = new BookerHelpPage();
		 myBookerPage = new MyBookerPage();
		 trolleyPage = new TrolleyPage();
		 productDetailsPage = new ProductDetailsPage();
		 additionalInformationPage= new AdditionalInformationPage();
		 orderSummaryPage = new OrderSummaryPage();
		 paymentPage = new PaymentPage();
		 orderConfirmationPage = new OrderConfirmationPage();
		 whatIsYourBusinessPage = new WhatIsYourBusinessPage();
		 createAnAccountPage = new CreateAnAccountPage();
		 chooseYourScannerPage = new ChooseYourScannerPage();
		 uploadsCS3000Page = new UploadsCS3000Page();
		 scannerValidateBarcodePage = new ScannerValidateBarcodePage();
		 kycFormPage = new KycFormPage();
		 creditComponentOnMyAccountPage = new CreditComponentOnMyAccountPage();
		 tnCPage = new TnCPage();
		 kycDocumentSignPage = new KycDocumentSignPage();
		 kycStageCompletionPage = new KycStageCompletionPage();
	}
}
