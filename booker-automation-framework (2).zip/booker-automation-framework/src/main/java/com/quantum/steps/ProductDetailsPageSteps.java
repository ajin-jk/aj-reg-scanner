package com.quantum.steps;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.quantum.utils.ReportUtils;

import java.util.Map;

public class ProductDetailsPageSteps extends AbstractSteps {
    public static Map<String,String> productDetails;
    @QAFTestStep(description="I should see product code as {0} and product name as {1} in the product details page")
    public void iShouldSeeProductCodeAsAndProductNameAsInTheProductDetailsPage(String productCode,String productDesc){
        productDetails = productDetailsPage.getProductInformation();
        ReportUtils.logAssert("verifying product code in product details page", productDetails.get("code").equalsIgnoreCase(productCode));
        ReportUtils.logAssert("verifying product name in product details page", productDetails.get("description").toLowerCase().trim().contains(productDesc.toLowerCase().trim()));
    }

    @QAFTestStep(description="I should see product price with including and excluding VAT")
    public void iShouldSeeProductPriceWithIncludingAndExcludingVAT(){
        Double priceExcludingVat = Double.parseDouble(productDetails.get("priceExcludingVat").replace("£",""));
        Double priceIncludingVat = Double.parseDouble(productDetails.get("priceIncludingVat").replace("£",""));
        ConfigurationManager.getBundle().setProperty("priceExcludingVat",priceExcludingVat);
        ConfigurationManager.getBundle().setProperty("priceIncludingVat",priceIncludingVat);
        ReportUtils.logAssert("verifying product price excluding VAT in product details page", priceExcludingVat>0);
        ReportUtils.logAssert("verifying product price including VAT in product details page", priceIncludingVat>=priceIncludingVat);
    }

    @QAFTestStep(description="I add the product quantity as {0} to the basket")
    public void iAddTheProductQuantityAsToTheBasket(String quantity) throws InterruptedException {
        productDetailsPage.addProductQuantityToBasket(Integer.parseInt(quantity));
    }


    @QAFTestStep(description="I should see item is added into the basket")
    public void iShouldSeeItemIsAddedIntoTheBasket() throws InterruptedException {
        Double deliveryProductPrice = Double.parseDouble(ConfigurationManager.getBundle().getProperty("priceExcludingVat").toString());
        ReportUtils.logAssert("verifying product price excluding VAT in product details page", productDetailsPage.getProductPriceFromDeliveryBasket()==deliveryProductPrice);
    }

    @QAFTestStep(description="I should see product code as {0} and product name as {1} in the trolley page")
    public void iShouldSeeProductCodeAsAndProductNameAsInTheTrolleyPage(String productCode,String productDescription){
        ReportUtils.logAssert("verifying product code in Trolley", productDetailsList.get("code").contains(productCode));
        ReportUtils.logAssert("verifying product description in Trolley", productDetailsList.get("description").trim().toLowerCase().contains(productDescription.trim().toLowerCase()));
    }

}
