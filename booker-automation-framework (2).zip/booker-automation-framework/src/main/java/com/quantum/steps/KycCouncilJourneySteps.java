package com.quantum.steps;

import com.qmetry.qaf.automation.step.QAFTestStep;
import com.quantum.utils.ReportUtils;

public class KycCouncilJourneySteps extends AbstractSteps {

    @QAFTestStep(description="I should able to credit component on the my account page")
    public void iShouldAbleToCreditComponentOnTheMyAccountPage(){
        ReportUtils.logAssert("verifying credit component present or not", creditComponentOnMyAccountPage.checkingCreditComponentOnMyAccountPage());
    }

    @QAFTestStep(description="I click on the Apply for credit button")
    public void iClickOnTheApplyForCreditButton(){
        creditComponentOnMyAccountPage.clickingOnApplyForCreditButton();

    }
    @QAFTestStep(description="I am clicking on the start Credit application button on the T&C page")
    public void iAmClickingOnTheStartCreditApplicationButtonOnTheTCPage(){
        tnCPage.startingKYCApplicationFromKYCForm();
    }
    //I am choosing "Council / Local Authority" from trading style dropdown
    @QAFTestStep(description="I am choosing {0} from trading style dropdown")
    public void iAmChoosingAsTradingStyle(String journey){
        kycFormPage.choosingTradingStyle(journey);
    }
    @QAFTestStep(description="I am entering all mandatory fields available on the Business Information section")
    public void iAmEnteringAllMandatoryFieldsAvailableOnTheBusinessInformationSection(){
        kycFormPage.fillingMandatoryFieldsAvailableOnTheBusinessInformationSection();
    }
    @QAFTestStep(description="I am entering all mandatory fields available on the Proprietor Details section")
    public void iAmEnteringAllMandatoryFieldsAvailableOnTheProprietorDetailsSection(){
        kycFormPage.fillingMandatoryFieldsAvailableOnTheProprietorDetailsSection();
    }

    @QAFTestStep(description="I am entering all mandatory fields available on the Credit requirement section")
    public void iAmEnteringAllMandatoryFieldsAvailableOnTheCreditRequirementSection(){
        kycFormPage.fillingMandatoryFieldsAvailableOnTheCreditRequirementSection();
    }
    @QAFTestStep(description="I am submitting the KYC application")
    public void iAmSubmittingTheKYCApplication(){
        kycFormPage.clickingOnTheSubmitButton();
    }
    @QAFTestStep(description="I should able to navigate to the DocuSign page")
    public void iShouldAbleToNavigateToTheDocuSignPage(){
        ReportUtils.logAssert("verifying DocuSign page title", kycDocumentSignPage.checkingTitleOfTheDocuSignPage());

    }
    @QAFTestStep(description="I should able to complete the DocuSign procedure")
    public void iShouldAbleToCompleteTheDocuSignProcedure(){
        kycDocumentSignPage.completeDocumentSignSubmittingProcessForCouncilJourney();
        System.out.println("Done");

    }

    @QAFTestStep(description="I should able to decline the DocuSign document")
    public void iShouldAbleToDeclineTheDocuSignProcedure(){
        kycDocumentSignPage.decliningTheDocumentSignProcess();
        kycStageCompletionPage.clickingOnBackToMyAccountButtonOnStageCompletionPage();
    }
}
