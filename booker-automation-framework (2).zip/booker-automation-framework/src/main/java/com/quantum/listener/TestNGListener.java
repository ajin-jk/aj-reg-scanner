package com.quantum.listener;

import java.time.Duration;

import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import org.openqa.selenium.By;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import static com.quantum.utils.MobileUtils.*;
import com.quantum.utils.DeviceUtils;

public class TestNGListener implements ITestListener {


	@Override
	public void onTestStart(ITestResult result) {
		QAFExtendedWebDriver driver = DeviceUtils.getQAFDriver();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(120));
		if(isAndroid()){
			try {
				driver.findElement(By.xpath("//*[@text='Continue']")).click();
				QAFExtendedWebElement element = driver.findElement(By.xpath("//*[@text='Allow']"));
				element.waitForVisible(3000);
				element.click();
			}
			catch (Exception e){}
		} else if (isIOS()) {
			try {
				driver.findElement(By.xpath("//*[@text='Never for this Website']")).click();
			}
			catch (Exception e){}
		}
	}

	@Override
	public void onTestSuccess(ITestResult result) {
	}

	@Override
	public void onTestFailure(ITestResult result) {
	}

	@Override
	public void onTestSkipped(ITestResult result) {
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
	}

	@Override
	public void onStart(ITestContext context) {
	}

	@Override
	public void onFinish(ITestContext context) {
	}
}
