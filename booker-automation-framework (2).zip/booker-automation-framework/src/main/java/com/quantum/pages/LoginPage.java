package com.quantum.pages;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import com.quantum.utils.ReportUtils;
import org.openqa.selenium.remote.RemoteWebElement;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.PropertyUtil;
import static com.quantum.utils.MobileUtils.*;


public class LoginPage extends WebDriverBaseTestPage<WebDriverTestPage> {
    @Override
    protected void openPage(PageLocator locator, Object... args) {
    }
    PropertyUtil props = ConfigurationManager.getBundle();

    @FindBy(locator = "#Email")
    private QAFExtendedWebElement emailAddressTextBox;

    @FindBy(locator = "#Password")
    private QAFExtendedWebElement passWordTextBox;

    @FindBy(locator = ".btn.login-btn.ml-3.ml-md-1.mr-md-3.mr0.col-6.col-md-4")
    private QAFExtendedWebElement loginButton;

    @FindBy(locator = "login.logout.button")
    private QAFExtendedWebElement logoutButton;

	@FindBy(locator = "login.sidebar.menu")
	private QAFExtendedWebElement mobileSideMenu;

    @FindBy(locator = "#IsRead")
    private QAFExtendedWebElement readBulletinMessage;

    @FindBy(locator = "//button[@class='ml-3 btn btn-success' and @type='submit']")
    private QAFExtendedWebElement continueButton;
    
    @FindBy(locator = "css=.font-weight-bold:nth-child(1)")
    private QAFExtendedWebElement loginHeaderText;
    
    @FindBy(locator = "link=Need help logging in?")
    private QAFExtendedWebElement needHelpLoggingInLink;
    
    @FindBy(locator = "link=Forgotten your password?")
    private QAFExtendedWebElement forgottenYourPasswordLink;
    
    @FindBy(locator = "#booker_soft_logged > div > form > div.d-flex.ml-3.mb-3.max-width-control.justify-content-end > a")
    private QAFExtendedWebElement cancelButton;
    
    @FindBy(locator = "#booker_soft_logged > div > form > div.validation-summary-errors.alert.alert-danger > ul > li")
    private List<QAFExtendedWebElement> validationMessagesList;
    
    @FindBy(locator = "css=#booker_soft_logged > div > form > div:nth-child(5) > span")
    private QAFExtendedWebElement customerNumberLabel;
    
    public void loginToBookerApplication(){
        emailAddressTextBox.sendKeys(props.getString("booker.emailId"));
        passWordTextBox.sendKeys(props.getString("booker.password"));
        loginButton.click();
        try {
			if(isIOS()){
				ocrClickByText("Not Now");
			}
            readBulletinMessage.click();
            continueButton.click();
        }
        catch (Exception e){
        }
    }

    public boolean isLoginSuccessful() throws InterruptedException {
		if(isAndroid() || isIOS()){
			mobileSideMenu.waitForVisible(5000);
			mobileSideMenu.click();
			Thread.sleep(1000);
			ocrScroll("My Account", "SWIPE_UP");
			return logoutButton.isDisplayed();
		}
        return logoutButton.isDisplayed();
    }

	public String getLoginHeader() {
		loginHeaderText.waitForVisible(3000);
		return loginHeaderText.getText();
	}
	
	public boolean isNeedHelpLoggingInLinkExists() {
		try {
			needHelpLoggingInLink.waitForVisible(5000);
			return needHelpLoggingInLink.isDisplayed();
		} catch (Exception e) {
			return false;
		}		
	}
	
	public boolean isForgottenPasswordLinkExists() {
		try {
			forgottenYourPasswordLink.waitForVisible(5000);
			return forgottenYourPasswordLink.isDisplayed();
		} catch (Exception e) {
			return false;
		}	
	}

	public void clickIsNeedHelpLoggingInLink() {
		needHelpLoggingInLink.click();		
	}
	
	public void clickForgottenPasswordInLink() {
		forgottenYourPasswordLink.click();		
	}
	
	public void clickCancelButton() {
		cancelButton.click();
	}
	
	public void clickLoginButton() {
		loginButton.click();
		if(isIOS()){
			ocrClickByText("Not Now");
		}
	}
	
	public List<String> getValidationMessages(){
		List<String> validationMessagesValues=validationMessagesList.stream().map(RemoteWebElement::getText).collect(Collectors.toList());
		return validationMessagesValues;
	}

	public void enterEmailId(String emailId) {
        emailAddressTextBox.sendKeys(emailId);
	}
	
	public void enterPassword(String password) {
		passWordTextBox.sendKeys(password);
	}

	public String getCustomerNumber() {
		customerNumberLabel.waitForVisible(60000);
		return customerNumberLabel.getText();
	}

	public void loginToBookerApplicationAs(String  userName, String password){
		emailAddressTextBox.sendKeys(userName);
		passWordTextBox.sendKeys(password);
		loginButton.click();
		try {
			if(isIOS()){
				ocrClickByText("Not Now");
			}
			readBulletinMessage.click();
			continueButton.click();
		}
		catch (Exception e){
		}
	}

	public String getValueFromPageSource(String text){
		String pageSource = driver.getPageSource().toString();
		String findText = "\""+text+"\":\"";
		int index = pageSource.indexOf(findText);
		index += findText.length();
		int endIndex = pageSource.indexOf("\"", index);
		String foundText = pageSource.substring(index, endIndex);
		return foundText;
	}

	public void testEmail(String eMail){
		emailAddressTextBox.waitForVisible(3000);
		emailAddressTextBox.sendKeys(eMail);
	}

	public void testPassword(String pasword){
		passWordTextBox.waitForVisible(4000);
		passWordTextBox.sendKeys(pasword);
	}


}
