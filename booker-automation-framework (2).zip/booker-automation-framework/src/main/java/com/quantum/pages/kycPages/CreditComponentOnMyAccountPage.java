package com.quantum.pages.kycPages;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import org.openqa.selenium.JavascriptExecutor;

public class CreditComponentOnMyAccountPage extends WebDriverBaseTestPage<WebDriverTestPage> {
    //We have more scenarios relating to the credit component, so created separate page object model for this component
    @Override
    protected void openPage(PageLocator pageLocator, Object... objects) {

    }
    @FindBy(locator = "//*[@id='credit-account']/div[1]/h4")
    private QAFExtendedWebElement creditComponentHeader;

    @FindBy(locator = "//*[@id='credit-account']/div[2]/a")
    private QAFExtendedWebElement applyForCreditButton;

    //Credit component header
    public Boolean checkingCreditComponentOnMyAccountPage() {

        //to perform Scroll on application using Selenium
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,450)", "");
        creditComponentHeader.waitForVisible(2000);
        return creditComponentHeader.isDisplayed();
    }
    //status 0
    public void clickingOnApplyForCreditButton() {
        applyForCreditButton.click();
    }

}
