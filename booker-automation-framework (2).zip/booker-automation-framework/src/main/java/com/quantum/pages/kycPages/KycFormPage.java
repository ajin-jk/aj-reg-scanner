package com.quantum.pages.kycPages;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.PropertyUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class KycFormPage extends WebDriverBaseTestPage<WebDriverTestPage> {

    PropertyUtil props = ConfigurationManager.getBundle();

    @Override
    protected void openPage(PageLocator locator, Object... args) {
    }

    Duration sd = Duration.ofSeconds(20);
    WebDriverWait wait = new WebDriverWait(driver, sd);

    @FindBy(locator = "//kyc-input[@data-type='select' and @data-label='Trading style']")
    private QAFExtendedWebElement tradingStyle;
    @FindBy(locator = "//kyc-input[@data-type='text' and @data-label='Council Name']")
    private QAFExtendedWebElement councilNAme;

    public void choosingTradingStyle(String journey) {
        // Wait until the shadow host element is available
        WebElement shadowHost = wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("kyc-input[data-type='select']")));
        SearchContext shadowRoot = (SearchContext ) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot", shadowHost);
        // Now locate the <select> element inside the shadow DOM
        WebElement selectElement = shadowRoot.findElement(By.cssSelector("select"));
        wait.until(ExpectedConditions.elementToBeClickable(selectElement));
        selectElement.click();

        List<WebElement> options = selectElement.findElements(By.tagName("option"));
        for (WebElement option : options) {
            if (option.getText().equals(journey)) {
                option.click();
                break;  // Break out of the loop once the option is selected
            }
        }
    }
    //Business Information Section ----------------
    public void fillingMandatoryFieldsAvailableOnTheBusinessInformationSection() {
        sendingValueToCouncilNameField();
        selectingRegisteredOfficeAddress();
        enteringTelephoneNumber();
        enteringEmailAdd();
        enteringConfirmEmail();
        dateTradingCommenced();
        enteringNumberOfYearsAtTheAddress();
        choosingNoOtherAccountsWithBooker();
        clickingOnNextButtonAvailableOnBusinessInformationSection();
    }
    public void sendingValueToCouncilNameField(){
        SearchContext shadowConcil = driver.findElement(By.xpath("//kyc-input[@data-type='text' and @data-label='Council Name']")).getShadowRoot();
        shadowConcil.findElement(By.cssSelector("input[type='text'][minlength='2'][maxlength='40']")).sendKeys("This is AJ");
    }
    public void selectingRegisteredOfficeAddress(){
        SearchContext shadowRegOfficePostcode = driver.findElement(By.xpath("/html/body/main/div/div/kyc-accordion/accordion-tab[1]/tab-content/div/address-box[2]")).getShadowRoot();
        WebElement postcodeInput = shadowRegOfficePostcode.findElement(By.cssSelector("input[name='postcode']"));
        postcodeInput.clear();
        postcodeInput.sendKeys("NN3 3HH");

        WebElement addressLookup = shadowRegOfficePostcode.findElement(By.cssSelector("button.address-lookup-btn"));
        addressLookup.click();

        WebElement selectAddress = shadowRegOfficePostcode.findElement(By.cssSelector("select[name='addressSelect']"));
        wait.until(ExpectedConditions.elementToBeClickable(selectAddress));
        Select select = new Select(selectAddress);
        select.selectByIndex(3);
    }
        //This is for my reference, below steps also will work - Commented by Ajin
//        WebElement selectAddress = shadowRegOfficePostcode.findElement(By.cssSelector("select[name='addressSelect']"));
//        wait.until(ExpectedConditions.elementToBeClickable(selectAddress));
//        selectAddress.click();
//        List<WebElement> options = selectAddress.findElements(By.tagName("option"));
//        System.out.println(options.get(2).getText());
//        WebElement addressSelectedOption = options.get(2);
//        addressSelectedOption.click();
    public void enteringTelephoneNumber(){
        SearchContext shadowRegCharityNumber = driver.findElement(By.cssSelector("kyc-input[data-name='TelephoneNumber']")).getShadowRoot();
        WebElement regCharityNumberInputBox = shadowRegCharityNumber.findElement(By.cssSelector("div > input[type=tel]"));
        regCharityNumberInputBox.clear();
        regCharityNumberInputBox.sendKeys("0123456789");
    }

    public void enteringEmailAdd(){
        SearchContext shadowEmail = driver.findElement(By.cssSelector("kyc-input[id='user-email']")).getShadowRoot();
        WebElement emailAdd = shadowEmail.findElement(By.cssSelector("input[type='email']"));
        emailAdd.clear();
        emailAdd.sendKeys("test@test.com");
    }

    public void enteringConfirmEmail(){
        SearchContext shadowConfirmEmail = driver.findElement(By.cssSelector("kyc-input[data-name='ConfirmEmailAddress']")).getShadowRoot();
        WebElement emailConfirmAdd = shadowConfirmEmail.findElement(By.cssSelector("input[type='email']"));
        emailConfirmAdd.clear();
        emailConfirmAdd.sendKeys("test@test.com");
    }

    public void dateTradingCommenced(){
        SearchContext shadowDateTradingCommenced = driver.findElement(By.cssSelector("kyc-input[data-name='DateTradingCommenced']")).getShadowRoot();
        WebElement dateTradingCommenced = shadowDateTradingCommenced.findElement(By.cssSelector("input[type='date']"));
        dateTradingCommenced.sendKeys("05/06/2024");
    }

    public void enteringNumberOfYearsAtTheAddress(){
        SearchContext shadowDateTradingCommenced = driver.findElement(By.cssSelector("kyc-input[data-name='NumberOfYearsAtTradingAddress']")).getShadowRoot();
        WebElement dateTradingCommenced = shadowDateTradingCommenced.findElement(By.cssSelector("input[type='text']"));
        dateTradingCommenced.sendKeys("5");
    }

    public void choosingNoOtherAccountsWithBooker(){
        SearchContext shadowBookerAccountDropdown = driver.findElement(By.cssSelector("kyc-input[data-name='DoYouHoldAnyOtherAccountsWithBooker']")).getShadowRoot();
        WebElement selectOption = shadowBookerAccountDropdown.findElement(By.cssSelector("select"));
        Select select = new Select(selectOption);
        select.selectByIndex(2);
    }
    public void clickingOnNextButtonAvailableOnBusinessInformationSection(){
        SearchContext shadowNextBtn = driver.findElement(By.cssSelector("next-button[data-tab='0']")).getShadowRoot();
        shadowNextBtn.findElement(By.cssSelector("button.next-button")).click();
    }
    //Proprietor Details Section -----------------
    public void fillingMandatoryFieldsAvailableOnTheProprietorDetailsSection() {
        selectingAPosition();
        clickingOnNextButtonAvailableOnTheProprietorDetailsSection();
    }
    public void selectingAPosition(){
        SearchContext shadowPosition = driver.findElement(By.cssSelector("kyc-input[id='position-field']")).getShadowRoot();
        WebElement selectOption = shadowPosition.findElement(By.cssSelector("select"));
        Select select = new Select(selectOption);
        select.selectByIndex(2);
    }
    public void clickingOnNextButtonAvailableOnTheProprietorDetailsSection(){
        SearchContext shadowNextBtn = driver.findElement(By.cssSelector("next-button[data-tab='1']")).getShadowRoot();
        shadowNextBtn.findElement(By.cssSelector("button.next-button")).click();
    }
    //Credit Requirement Section -----------------
    public void fillingMandatoryFieldsAvailableOnTheCreditRequirementSection() {
        enteringAverageWeeklySpend();
        enteringCreditLimitRequired();
        selectingCreditTye();
    }
    private void enteringAverageWeeklySpend() {
        SearchContext shadowAvgWeeklySpend = driver.findElement(By.cssSelector("kyc-input[data-name='AverageWeeklySpend']")).getShadowRoot();
        shadowAvgWeeklySpend.findElement(By.cssSelector("input[type='text']")).sendKeys("1500");
    }
    private void enteringCreditLimitRequired() {
        SearchContext shadowCreditLimitRequired = driver.findElement(By.cssSelector("kyc-input[data-name='CreditLimitRequired']")).getShadowRoot();
        shadowCreditLimitRequired.findElement(By.cssSelector("input[type='text']")).sendKeys("6500");
    }
    private void selectingCreditTye() {
        SearchContext shadowCreditType = driver.findElement(By.cssSelector("kyc-input[data-name='CreditType']")).getShadowRoot();
        WebElement selectOption = shadowCreditType.findElement(By.cssSelector("select"));
        Select select = new Select(selectOption);
        select.selectByIndex(1);
    }
    //Final KYC form Submission
    public void clickingOnTheSubmitButton() {
        SearchContext shadowFinalSubmit = driver.findElement(By.xpath("//*[@id='kyc-application-form']/next-button")).getShadowRoot();
        shadowFinalSubmit.findElement(By.cssSelector("button.next-button.submit")).click();
    }



}
