package com.quantum.pages;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.PropertyUtil;

public class BookerHelpPage extends WebDriverBaseTestPage<WebDriverTestPage>{

	PropertyUtil props = ConfigurationManager.getBundle();

	@Override
	protected void openPage(PageLocator locator, Object... args) {
	}

	@FindBy(locator = "#Booker_Help > div > h2")
	private QAFExtendedWebElement bookerHelperHeader;

	@FindBy(locator = "#Booker_Help > div > div > a")
	private QAFExtendedWebElement returnHomeButton;
	
	//
	
	public boolean isBookerHelpPageLoaded() {
		try {
			bookerHelperHeader.waitForVisible(30000);
			return bookerHelperHeader.isDisplayed();
		} catch (Exception e) {
			return false;
		}
	}
	
	public String getHeaderText() {
		return bookerHelperHeader.getText();
	}
	
	public void clickReturnHome() {
		returnHomeButton.click();
	}
	
	public boolean isReturnHomeButtonExists() {
		try {
			return returnHomeButton.isDisplayed();
		} catch (Exception e) {
			return false;
		}
	}
}
