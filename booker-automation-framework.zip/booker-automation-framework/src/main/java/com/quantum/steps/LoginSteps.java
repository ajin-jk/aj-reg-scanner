package com.quantum.steps;

import com.qmetry.qaf.automation.step.QAFTestStep;
import java.util.List;
import com.quantum.utils.ReportUtils;

public class LoginSteps extends AbstractSteps {
  

    @QAFTestStep(description="I login to Booker with valid email and password")
    public void iLoginToBookerWithValidEmailAndPassword() {
        loginPage.loginToBookerApplication();
    }

    @QAFTestStep(description="I should be able to login successfully")
    public void iShouldBeAbleToLoginSuccessfully() throws InterruptedException {
        boolean loginSuccessful = loginPage.isLoginSuccessful();
        ReportUtils.logAssert("verifying login is successful", loginSuccessful==true);
    }
    
    @QAFTestStep(description="I should see Login page header as {0}")
    public void iShouldSeeLoginPageHeaderAs(String hearder){
    	String headerText = loginPage.getLoginHeader();
    	ReportUtils.logAssert("verifying login header text is matching or not", headerText.equalsIgnoreCase(hearder));
    }
        
    @QAFTestStep(description="I should see link for Need help logging in")
    public void iShouldSeeLinkForNeedHelpLoggingIn(){
    	ReportUtils.logAssert("verifying Need help logging in? link exists", loginPage.isNeedHelpLoggingInLinkExists());
    }
    
    @QAFTestStep(description="I click on Need help logging in link")
    public void iClickOnNeedHelpLoggingInLink(){
    	loginPage.clickIsNeedHelpLoggingInLink();
    }
    
    @QAFTestStep(description="I click on Cancel button")
    public void iClickOnCancelButton(){
    	loginPage.clickCancelButton();;
    }
    
    @QAFTestStep(description="I click on Login button on Login Page")
    public void iClickOnLoginButtonOnLoginPage(){
    	loginPage.clickLoginButton();
    }
    
    @QAFTestStep(description="I should see login error validation message as {0}")
    public void iShouldSeeLoginErrorValidationMessageAs(String validationMessage){
    	List<String> validationMessagesList = loginPage.getValidationMessages();
    	ReportUtils.logAssert("verifying login error validation messages", validationMessagesList.contains(validationMessage));
    }
    
    @QAFTestStep(description="I enter invalid email id as {0}")
    public void iEnterInvalidEmailIdAs(String emailId){
    	loginPage.enterEmailId(emailId);
    }
    
    @QAFTestStep(description="I enter valid email id")
    public void iEnterValidEmailId(){
    	loginPage.enterEmailId(props.getString("booker.emailId"));
    }
    
    @QAFTestStep(description="I enter password as {0} which does not match with the above emailId")
    public void iEnterPasswordAsWhichDoesNotMatchWithTheAboveEmailId(String password){
    	loginPage.enterPassword(password);
    }
    
    @QAFTestStep(description="I should be redirected to Login Page with valid customer number as {0}")
    public void iShouldBeRedirectedToLoginPageWithValidCustomerNumberAs(String customerNumber){
    	String customerNumberValueActual = loginPage.getCustomerNumber(); 
    	ReportUtils.logAssert("verifying customer number is displayed in Login Page", customerNumberValueActual.equalsIgnoreCase(customerNumberValueActual));
    }

    @QAFTestStep(description="I login to Booker Application with customer email as {0} and customer password as {1}")
    public void iLoginToBookerApplicationWithCustomerEmailAsAndCustomerPasswordAs(String userName,String password){
        loginPage.loginToBookerApplicationAs(userName,password);
    }

    @QAFTestStep(description="I should be able to see customer fascia as {0}")
    public void iShouldBeAbleToSeeCustomerFasciaAs(String fasciaId){
        String customerFasciaId=loginPage.getValueFromPageSource("customer_fascia");
        ReportUtils.logAssert("verifying customer fascia is displayed in page source", customerFasciaId.equalsIgnoreCase(fasciaId));
    }

    @QAFTestStep(description="I login to Booker Application with customer email as {0}")
    public void iLoginToBookerApplicationWithCustomerEmailAs(String eMail){
        loginPage.testEmail(eMail);
    }

    @QAFTestStep(description="I enter customer password as {0}")
    public void iEnterCustomerPasswordAs(String pswd){
        loginPage.testPassword(pswd);
    }

}
