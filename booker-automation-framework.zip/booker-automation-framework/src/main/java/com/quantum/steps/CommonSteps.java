package com.quantum.steps;

import static com.quantum.utils.CommonUtils.getCurrentWebUrl;

import com.qmetry.qaf.automation.step.QAFTestStep;
import com.quantum.utils.ReportUtils;

public class CommonSteps extends AbstractSteps {

    @QAFTestStep(description="I should see url relative path as {0}")
    public void iShouldSeeUrlRelativePath(String relativeUrl) throws InterruptedException {
        Thread.sleep(5000);
    	ReportUtils.logAssert("verifying relative url", getCurrentWebUrl().contains(relativeUrl));
    }

    @QAFTestStep(description="I should see url relative path as {0}{1}")
    public void iShouldSeeUrlRelativePathAs(String relativeUrl,String relativeUrl1){
        String currentUrl = getCurrentWebUrl().replace("%20","");
        ReportUtils.logAssert("verifying relative url", currentUrl.contains(relativeUrl+relativeUrl1));
    }
}
