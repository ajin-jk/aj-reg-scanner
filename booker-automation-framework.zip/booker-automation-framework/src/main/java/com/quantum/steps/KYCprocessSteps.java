package com.quantum.steps;

import com.qmetry.qaf.automation.step.QAFTestStep;
import com.quantum.utils.ReportUtils;

public class KYCprocessSteps extends AbstractSteps{






    @QAFTestStep(description="I should able to credit component on the my account page")
    public void iShouldAbleToCreditComponentOnTheMyAccountPage(){
        ReportUtils.logAssert("verifying credit component present or not", kycProcessPage.checkingCreditComponentOnMyAccountPage());
    }


    @QAFTestStep(description="I click on the Apply for credit button")
    public void iClickOnTheApplyForCreditButton(){
        kycProcessPage.clickingOnApplyForCreditButton();

    }


    @QAFTestStep(description="I am starting KYC application from T&C page")
    public void iAmStartingKYCApplicationFromTCPage(){
        kycProcessPage.startingKYCApplicationFromKYCForm();
    }

}
