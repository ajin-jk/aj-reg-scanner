package com.quantum.steps;

import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ReportUtils;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.Select;

@QAFTestStepProvider
public class CreateAnAccountPageSteps extends AbstractSteps {



    @QAFTestStep(description="I should able to navigate to Create an account page")
    public void iShouldAbleToNavigateToCreateAnAccountPage(){
        String headerName = "Create an account";
        ReportUtils.logAssert("Checking create an account page loaded", headerName.equals(createAnAccountPage.checkingCreateAnAccountPageLoaded().toString()));
        ReportUtils.logAssert("Checking the background color of About you tab", createAnAccountPage.checkingBGColorAboutYouAlone().contains("Blue"));
    }

    @QAFTestStep(description="I should able to fill all mandatory details available on the About You module")
    public void iShouldAbleToFillAllMandatoryDetailsAvailableOnTheAboutYouModule(){
        createAnAccountPage.fillingMandatoryFieldsOnAboutYouModule();
    }

    @QAFTestStep(description="I click on Next button available on the About you module")
    public void iClickOnNextButtonAvailableOnTheAboutYouModule(){
        ReportUtils.logAssert("Verifying validations in the About you module ", createAnAccountPage.clickingOnNextButtonOnAboutYouModule().contains("Green"));
    }

    @QAFTestStep(description="I should able to see my selected business {0} within the input of the Business Sector field as read only")
    public void iShouldAbleToSeeMySelectedBusinessWithinTheInputOfTheBusinessSectorFieldAsReadOnly(String business){
       //ReportUtils.logAssert("Checking the value available on Business Sector ", createAnAccountPage.checkingValueAppearedOnBusinessSector(business));
        createAnAccountPage.checkingValueAppearedOnBusinessSector(business);
    }

    @QAFTestStep(description="I should able to fill all mandatory details available on the Your business module")
    public void iShouldAbleToFillAllMandatoryDetailsAvailableOnTheYourBusinessModule(){
        createAnAccountPage.enteringMandatoryDetailsOnYourBusinessModule();
    }

    @QAFTestStep(description="I click on Next button available on the Your business module")
    public void iClickOnNextButtonAvailableOnTheYourBusinessModule(){
        createAnAccountPage.clickingOnNextButtonAvailableONBusinessModule();
    }

    @QAFTestStep(description="I should able to see Your Branch module")
    public void iShouldAbleToSeeYourBranchModule(){
        createAnAccountPage.checkingBranchResults();
    }

    @QAFTestStep(description="I click on Select Branch button available on the most recent branch")
    public void iClickOnSelectBranchButtonAvailableOnTheMostRecentBranch(){
        createAnAccountPage.selectingFirstBranchFromTheList();
    }

    @QAFTestStep(description="I should able to see selected branch details on the Your branch module")
    public void iShouldAbleToSeeSelectedBranchDetailsOnTheYourBranchModule(){
        createAnAccountPage.checkingSelectedBranchDetails();
    }

    @QAFTestStep(description="I click on I'm not a robot checkbox")
    public void iClickOnIMNotARobotCheckbox() throws InterruptedException {
        createAnAccountPage.test();
    }
    @QAFTestStep(description="I click on the Submit button")
    public void iClickOnTheSubmitButton(){
        createAnAccountPage.test1();
    }

    @QAFTestStep(description="I should able to see my new customer number on registration confirmation page")
    public void iShouldAbleToSeeMyNewCustomerNumberOnRegistrationConfirmationPage(){
        createAnAccountPage.test2();
    }

}
