package com.quantum.pages;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.PropertyUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;


public class AdditionalInformationPage extends WebDriverBaseTestPage<WebDriverTestPage> {
    @Override
    protected void openPage(PageLocator locator, Object... args) {
    }
    PropertyUtil props = ConfigurationManager.getBundle();

    @FindBy(locator = "#checkout-step-1 > main > div > div > form > div.nav-buttons.mt-3 > button")
    private QAFExtendedWebElement proceedButton;

    @FindBy(locator = "#checkout-step-1 > main > form > div > div.nav-buttons > button.btn.green-btn.mb-2.ml-2")
    private QAFExtendedWebElement proceedButtonForClickAndCollect;

    public void clickProceedToCheckoutButton(){
        proceedButton.waitForVisible(5000);
        proceedButton.click();
    }

    public void clickProceedToCheckoutButtonForClickNCollectCustomer(){
        proceedButtonForClickAndCollect.waitForVisible(5000);
        proceedButtonForClickAndCollect.click();
    }

    public void chooseACollectionSlot(){
        //locate the table
        QAFExtendedWebElement table = driver.findElement(By.cssSelector(".calendar"));

        //finding all available slots
        List<WebElement> availableSlots = table.findElements(By.cssSelector(".available-slot"));
        if(!availableSlots.isEmpty()){
            WebElement firstAvailableSlot = availableSlots.get(0);

            // Print the text of the slot to confirm
            System.out.println("First available slot text: " + firstAvailableSlot.getAttribute("onClick"));

            // Click the first available slot
            firstAvailableSlot.click();
        }

    }
}
