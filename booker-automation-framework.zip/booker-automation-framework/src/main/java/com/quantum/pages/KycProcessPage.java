package com.quantum.pages;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.PropertyUtil;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

public class KycProcessPage extends WebDriverBaseTestPage<WebDriverTestPage> {

    PropertyUtil props = ConfigurationManager.getBundle();

    @Override
    protected void openPage(PageLocator locator, Object... args) {
    }

    @FindBy(locator = "//*[@id='credit-account']/div[1]/h4")
    private QAFExtendedWebElement creditComponentHeader;

    @FindBy(locator = "//*[@id='credit-account']/div[2]/a")
    private QAFExtendedWebElement applyForCreditButton;

    @FindBy(locator = "//*[@id='booker_1termsconditions']/form/div[1]/div[2]/div[2]/div/div/label")
    private QAFExtendedWebElement checkBoxPrivacyPolicy;

    @FindBy(locator = "//*[@id='booker_1termsconditions']/form/div[1]/div[2]/div[3]/div/div/label")
    private QAFExtendedWebElement checkBoxOver18;
    @org.openqa.selenium.support.FindBy(css = "button#startApp")
    private QAFExtendedWebElement buttonStartCreditApplication;

    public Boolean checkingCreditComponentOnMyAccountPage() {

        //to perform Scroll on application using Selenium
            JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("window.scrollBy(0,450)", "");
        creditComponentHeader.waitForVisible(2000);
        return creditComponentHeader.isDisplayed();


    }

    public void clickingOnApplyForCreditButton() {
        applyForCreditButton.click();
    }

    public void startingKYCApplicationFromKYCForm() {
        //to perform Scroll on application using Selenium
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,450)", "");

        checkBoxPrivacyPolicy.click();
        checkBoxOver18.click();
        buttonStartCreditApplication.click();

    }
}
