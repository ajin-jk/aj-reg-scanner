package com.quantum.pages;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.PropertyUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class ProductDetailsPage extends WebDriverBaseTestPage<WebDriverTestPage> {
    @Override
    protected void openPage(PageLocator locator, Object... args) {
    }

    PropertyUtil props = ConfigurationManager.getBundle();

    @FindBy(locator = ".product-id")
    private QAFExtendedWebElement productId;

    @FindBy(locator = "#product_detail > div> div > h4")
    private QAFExtendedWebElement productDescription;

    @FindBy(locator = ".filaDesktop .price")
    private QAFExtendedWebElement priceExcludingVAT;

    @FindBy(locator = ".filaDesktop .price2")
    private QAFExtendedWebElement priceIncludingVAT;

    @FindBy(locator = ".filaDesktop .numbers-only.product-quantity+.plus-minus-icon")
    private QAFExtendedWebElement productQuantityPlusIcon;

    public Map<String, String> getProductInformation() {
        Map<String, String> productDetails = new HashMap<String, String>();
        productId.waitForVisible(30000);
        productDetails.put("description", productDescription.getText());
        productDetails.put("priceExcludingVat", priceExcludingVAT.getText());
        productDetails.put("priceIncludingVat", priceIncludingVAT.getText());
        productDetails.put("code", productId.getText());
        return productDetails;
    }

    public void addProductQuantityToBasket(int qty) throws InterruptedException {
        Thread.sleep(10000);
        for (int i = 0; i < qty; i++) {
            productQuantityPlusIcon.waitForVisible(5000);
            productQuantityPlusIcon.click();
        }
    }

    public double getProductPriceFromDeliveryBasket() throws InterruptedException {
        Thread.sleep(5000);
        Double priceExcludingVat = null;
        List<WebElement> element = driver.findElements(By.cssSelector("span.pounds-label"));
        if(element.size()>1){
            priceExcludingVat = Double.parseDouble(element.get(1).getText().replace("£",""));
        }
        else{
            priceExcludingVat = Double.parseDouble(element.get(0).getText().replace("£",""));
        }
        return priceExcludingVat;
    }

}
