package com.quantum.pages.ScannerPages;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.PropertyUtil;
import org.openqa.selenium.JavascriptExecutor;

import java.util.HashMap;
import java.util.Map;

public class UploadsCS3000Page extends WebDriverBaseTestPage<WebDriverTestPage> {

    @Override
    protected void openPage(PageLocator locator, Object... args){
    }
    PropertyUtil props = ConfigurationManager.getBundle();

    @FindBy(locator = "choose.file.button")
    QAFExtendedWebElement chooseFileButton;    //choose.file.button=id=barcodes

    @FindBy(locator = "get.barcodes.add.to.delivery.trolley")
    QAFExtendedWebElement getBarcodesAddToOrderForDeliveryButton;


    public void uploadTheScannerFile() {
        Map param = new HashMap();
        param.put("fileLocation","PUBLIC:Invalid_ScannerDoc1.txt");
        Object result = driver.executeScript("perfecto:file:upload",param);

        chooseFileButton.waitForVisible(4000);
        chooseFileButton.sendKeys(result.toString());
    }

    public boolean checkingUploadButtonHasAppearedForDelivery(String buttonName) {
        return getBarcodesAddToOrderForDeliveryButton.getText().equalsIgnoreCase(buttonName);
    }

    public void selectingTheUploadButtonForDelivery(String buttonName) {
        if(buttonName.contains("Delivery")) {
            getBarcodesAddToOrderForDeliveryButton.click();
        }else {
            System.out.println("Click and collect trolley");
        }
    }
}
