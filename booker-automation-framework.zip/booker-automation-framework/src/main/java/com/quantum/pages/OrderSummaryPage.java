package com.quantum.pages;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.PropertyUtil;


public class OrderSummaryPage extends WebDriverBaseTestPage<WebDriverTestPage> {
    @Override
    protected void openPage(PageLocator locator, Object... args) {
    }
    PropertyUtil props = ConfigurationManager.getBundle();

    @FindBy(locator = ".radio-input:nth-child(1) > .checkmark:nth-child(2)")
    private QAFExtendedWebElement payByCardOption;

    @FindBy(locator = "#paymentOptionsButton")
    private QAFExtendedWebElement paymentOptionsButton;


    public void selectPayByCardOption(){
        payByCardOption.waitForVisible(5000);
        payByCardOption.click();
    }

    public void clickPaymentOptionsButton(){
        paymentOptionsButton.waitForVisible(5000);
        paymentOptionsButton.click();
    }
}
