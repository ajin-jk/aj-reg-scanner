package com.quantum.utils;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.PropertyUtil;
import com.qmetry.qaf.automation.util.StringUtil;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.IInvokedMethod;

import java.sql.Timestamp;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

public class CommonUtils {

	public static String allowedChars = "abcdefghijklmnopqrstuvwxyz";
	public static String allowedNumeric = "0123456789";

	public static int TIMEOUT_30 = 30000;

	public static void switchToFrame(String nameOrIndex) {
		if (StringUtil.isNumeric(nameOrIndex)) {
			int index = Integer.parseInt(nameOrIndex);
			new WebDriverTestBase().getDriver().switchTo().frame(index);
		} else {
			new WebDriverTestBase().getDriver().switchTo().frame(nameOrIndex);
		}
	}

	public static void switchBackToDefaultFrame() {
		new WebDriverTestBase().getDriver().switchTo().defaultContent();
	}

	public static int getDayOfMonth(int numberOfDaysToAdd) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DAY_OF_MONTH, numberOfDaysToAdd);
		Date modifiedDate = cal.getTime();
		return modifiedDate.getDate();
	}

	public static void selectValueFromDropDown(By element, String text) {
		QAFExtendedWebDriver driver = new WebDriverTestBase().getDriver();
		Select dropDownElement = new Select(driver.findElement(element));
		dropDownElement.selectByVisibleText(text);
	}

	public static void pressKey(Keys keys) {
		QAFExtendedWebDriver driver = new WebDriverTestBase().getDriver();
		Actions action = new Actions(driver);
		action.sendKeys(keys).build().perform();
	}

	public static int getNumberOfDaysTodayFromDate(Date date) {
		Date todaysDate = new Date();
		long diff = date.getTime() - todaysDate.getTime();
		return (int) TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
	}

	public static Map<String, String> getDatatableValues(List<Map<String, String>> dataList) {
		Map<String, String> newDataValues = new HashMap<>();
		for (Map<String, String> dataMap : dataList) {
			String FieldName = null;
			String FieldValue = null;
			for (Map.Entry<String, String> entry : dataMap.entrySet()) {
				if (entry.getKey().toString().equals("FieldName")) {
					FieldName = entry.getValue().toString();
				} else {
					FieldValue = entry.getValue().toString();
				}
			}
			newDataValues.put(FieldName, FieldValue);
		}
		return newDataValues;
	}

	public static int getMonthNumber(int numberOfDaysToAdd) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DAY_OF_MONTH, numberOfDaysToAdd);
		return cal.get(Calendar.MONTH);
	}

	public static int getYearNumber(int numberOfDaysToAdd) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DAY_OF_MONTH, numberOfDaysToAdd);
		return cal.get(Calendar.YEAR);
	}

	public static boolean selectDateFromDatePicker(By element, int day) {
		QAFExtendedWebDriver driver = new WebDriverTestBase().getDriver();
		List<WebElement> dateElements = driver.findElements(element);
		boolean bFlag = false;
		for (int i = 0; i < dateElements.size(); i++) {
			String val = dateElements.get(i).getText();
			if (val.equals(String.valueOf(day))) {
				dateElements.get(i).click();
				bFlag = true;
				break;
			}
		}
		return bFlag;
	}

	public static void waitForAvailableWebLicense(IInvokedMethod method) throws Exception, InterruptedException {
		PropertyUtil props = ConfigurationManager.getBundle();
		String methodName = method.getTestMethod().getMethodName();
		if (System.getProperty("threadCount") != null) {
			long threadCount = Math.round(Integer.parseInt(System.getProperty("threadCount").toString()) / 10);
			if (methodName.equalsIgnoreCase("setupMethod")) {
				if (props.getString("driver.name").equalsIgnoreCase("perfectoRemoteDriver")) {
					int counter = 1;
					int breaker = 100;
					while (getAvailableLicenseCount(props) < threadCount && counter < breaker) {
						int availableLicense = getAvailableLicenseCount(props);
						System.out.println("### Iteration: " + counter + ". Available license: " + availableLicense
								+ " is less than " + threadCount + "! Retrying after 10 seconds.");
						Thread.sleep(10000);
						counter++;
						if (counter == breaker) {
							break;
						}
					}
				}
				System.out.println("### Available web licenses: " + getAvailableLicenseCount(props));
			}
		}
	}

	static int getAvailableLicenseCount(PropertyUtil props) throws Exception {
		String cloudUrl = props.getString("remote.server").split("nexperience")[0];
		String securityToken = props.getString("perfecto.capabilities.securityToken");
		OkHttpClient client = new OkHttpClient().newBuilder().build();
		Request request = new Request.Builder().url(cloudUrl + "enforcement/api/v1/usageInfo/licenses/DESKTOP")
				.method("GET", null).addHeader("Content-Type", "application/json")
				.addHeader("Perfecto-Authorization", securityToken).build();
		Response response = client.newCall(request).execute();
		return Integer.parseInt(getResponseKeyValue(response, "available"));
	}

	static String getResponseKeyValue(Response response, String key) throws Exception {
		String jsonData = response.body().string();
		if (jsonData.contains("Failed 3 attempts to create access token in keycloak")) {
			throw new Exception(jsonData);
		}
		JSONObject obj = new JSONObject(jsonData);
		return obj.getJSONArray("licenseList").getJSONObject(0).get(key).toString();
	}


	public static String getValueFromDropDown(By element) {
		QAFExtendedWebDriver driver = new WebDriverTestBase().getDriver();
		Select dropDownElement = new Select(driver.findElement(element));
		String text = dropDownElement.getFirstSelectedOption().getText();
		return text;
	}

	public static boolean isElementDisplayed(By locatorBy) {
		try {
			return new WebDriverTestBase().getDriver().findElement(locatorBy).isDisplayed();
		} catch (Exception e) {
			return false;
		}
	}

	public static boolean isDisplayed(WebElement element) {
		try {
			return element.isDisplayed();
		} catch (Exception e) {
			return false;
		}
	}


	public static long getTimeStampNumber(){
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		return timestamp.getTime();
	}

	public static void enterInputText(By inputElementBy, String value) {
		QAFExtendedWebDriver driver = new WebDriverTestBase().getDriver();
		WebElement inputElement = driver.findElement(inputElementBy);
		inputElement.clear();
		inputElement.sendKeys(value);
	}
	
	public static String getCurrentWebUrl(){
		QAFExtendedWebDriver driver = new WebDriverTestBase().getDriver();
		return driver.getCurrentUrl();
	}
	public static String checkingBgColor(QAFExtendedWebElement element){
		String blueColor = "#2356AA";
		String greenColor = "#51af39";
		String backgroundColor = element.getCssValue("background-color");
		//Converting the bg color (RGB value) to hex format
		String hexValue = Color.fromString(backgroundColor).asHex();
		if(hexValue.equalsIgnoreCase(blueColor)){
			return "Blue";
		} else if (hexValue.equalsIgnoreCase(greenColor)) {
			return "Green";
		} else {
			return "other color found " + hexValue;
		}
	}

}
