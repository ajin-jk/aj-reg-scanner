package com.quantum.pages;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.PropertyUtil;

import java.util.Arrays;


public class OrderConfirmationPage extends WebDriverBaseTestPage<WebDriverTestPage> {
    @Override
    protected void openPage(PageLocator locator, Object... args) {
    }
    PropertyUtil props = ConfigurationManager.getBundle();

    @FindBy(locator = "#checkout-step4 > main > div > div > div.d-flex.justify-content-center.thank-you > div > h5")
    private QAFExtendedWebElement orderConfirmationMessage;

    @FindBy(locator = "#checkout-step4 > main > div > div > div.d-flex.justify-content-center.thank-you > div > ul > li > span")
    private QAFExtendedWebElement orderNumber;

    
    public String getOrderConfirmationMessage(){
        orderConfirmationMessage.waitForVisible(60000);
        return orderConfirmationMessage.getText();
    }

    public String getOrderNumber(){
        orderNumber.waitForVisible(5000);
        return orderNumber.getText();
    }

    public String getBRPOrderNumber(){
        orderNumber.waitForVisible(5000);
        String orderType = Arrays.toString(orderNumber.getText().split("-"));
        return orderType;
    }


}
