package com.quantum.steps;

import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.quantum.utils.ReportUtils;

@QAFTestStepProvider
public class WhatIsYourBusinessPageSteps extends AbstractSteps {

    @QAFTestStep(description="I select my business {0} from what is my business field")
    public void iSelectMyBusinessFromWhatIsMyBusinessField(String yourBusiness) throws InterruptedException {
        whatIsYourBusinessPage.selectYourBusiness(yourBusiness);
    }

    @QAFTestStep(description="I click on Create Your Account button")
    public void iClickOnCreateYourAccountButton() throws InterruptedException {
        whatIsYourBusinessPage.clickCreateYourBusinessButton();
    }

}
