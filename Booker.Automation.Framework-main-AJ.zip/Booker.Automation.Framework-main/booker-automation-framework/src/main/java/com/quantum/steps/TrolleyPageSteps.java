package com.quantum.steps;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.quantum.utils.ReportUtils;

public class TrolleyPageSteps extends AbstractSteps {

    @QAFTestStep(description="I should see Cancel and Remove all buttons are displayed")
    public void iShouldSeeCancelAndRemoveAllButtonsAreDisplayed(){
        ReportUtils.logAssert("verifying Continue button is displayed", trolleyPage.isContinueButtonDisplayed());
        ReportUtils.logAssert("verifying Cancel button is displayed", trolleyPage.isCancelButtonDisplayed());
    }

    @QAFTestStep(description="I click on Remove all button to remove all products from Trolley")
    public void iClickOnRemoveAllButtonToRemoveAllProductsFromTrolley(){
        trolleyPage.clickRemoveAll();
    }

    @QAFTestStep(description="I should see a message in trolley as {0}")
    public void iShouldSeeAMessageInTrolleyAs(String message){
        ReportUtils.logAssert("verifying warning message for empty trolley", trolleyPage.getEmptyTrolleyWarningMessage().toLowerCase().trim().contains(message.toLowerCase().trim()));
    }

    @QAFTestStep(description="I click on Continue button to remove all products")
    public void iClickOnContinueButtonToRemoveAllProducts(){
        trolleyPage.clickRemoveAllContinueButton();
    }


    @QAFTestStep(description="I should see order item price and quantity in the shopping list")
    public void iShouldSeeOrderItemPriceAndQuantityInTheShoppingList(){
        String stockedPrice = trolleyPage.getBranchStockedPrice().replace("£","");
        String deliveryProductPrice = ConfigurationManager.getBundle().getProperty("priceExcludingVat").toString();
        ReportUtils.logAssert("verifying branch stocked price in trolley", stockedPrice.equalsIgnoreCase(deliveryProductPrice));
    }


    @QAFTestStep(description="I should see number of cases as {0} in the checkout summary")
    public void iShouldSeeNumberOfCasesAsInTheCheckoutSummary(String cases){
        ReportUtils.logAssert("verifying number of cases in trolley", trolleyPage.getNoOfCases().contains(cases));
    }

    @QAFTestStep(description="I should see Including VAT Total Guide Price in the checkout summary")
    public void iShouldSeeIncludingVATTotalGuidePriceInTheCheckoutSummary(){
        String guidedPriceExVAT = trolleyPage.getTotalGuidedPriceExVAT().replace("£","");
        ReportUtils.logAssert("verifying total guided price excluding VAT in trolley", guidedPriceExVAT.equalsIgnoreCase(ConfigurationManager.getBundle().getProperty("priceExcludingVat").toString()));
    }

    @QAFTestStep(description="I should see Excluding VAT Total Guide Price in the checkout summary")
    public void iShouldSeeExcludingVATTotalGuidePriceInTheCheckoutSummary(){
        String guidedPriceIncludingVAT = trolleyPage.getTotalGuidedPriceIncludingVAT().replace("£","");
        ReportUtils.logAssert("verifying total guided price excluding VAT in trolley", guidedPriceIncludingVAT.equalsIgnoreCase(ConfigurationManager.getBundle().getProperty("priceIncludingVat").toString()));
    }

    @QAFTestStep(description="I click on proceed to checkout")
    public void iClickOnProceedToCheckout(){
        trolleyPage.clickProceedToCheckoutButton();
    }

}
