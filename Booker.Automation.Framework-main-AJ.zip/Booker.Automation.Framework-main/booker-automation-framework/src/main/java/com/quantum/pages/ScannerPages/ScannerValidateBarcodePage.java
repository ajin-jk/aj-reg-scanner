package com.quantum.pages.ScannerPages;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.PropertyUtil;

public class ScannerValidateBarcodePage extends WebDriverBaseTestPage<WebDriverTestPage> {

    @Override
    protected void openPage(PageLocator locator, Object... args){
    }
    PropertyUtil props = ConfigurationManager.getBundle();

    @FindBy(locator = "important.information.header")
    QAFExtendedWebElement headerImportantInformation;

    @FindBy(locator = "continue.button.important.information.page")
    QAFExtendedWebElement continueButtonOnInformationPage;

    @FindBy(locator = "successful.message.scanner.validation.page")
    QAFExtendedWebElement successfulMessageOnValidationPage;


    public void clickingOnContinueButtonOnImportantInformationPage() {
        System.out.println(headerImportantInformation.getText());
        continueButtonOnInformationPage.click();
    }

    public String verifyTheSuccessfulMessage() {
        return successfulMessageOnValidationPage.getText();
    }
}
