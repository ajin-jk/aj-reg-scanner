package com.quantum.steps;

import com.qmetry.qaf.automation.step.QAFTestStep;

import java.util.List;
import java.util.Map;

import static com.quantum.utils.CommonUtils.getDatatableValues;

public class PaymentDetailsPageSteps extends AbstractSteps {

    @QAFTestStep(description="I enter payment details card number as {0} card holder name as {1} and card expiry month {2} expiry year {3} and CSV as {4}")
    public void iEnterPaymentDetailsCardNumberAsCardHolderNameAsAndCardExpiryMonthExpiryYearAndCSVAs(String cardNumber,String cardHolderName,String expiryMonth,String expiryYear,String csv) throws InterruptedException {
        paymentPage.submitPaymentDetails(cardNumber,cardHolderName,expiryMonth,expiryYear,csv);
    }
}
