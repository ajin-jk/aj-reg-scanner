package com.quantum.pages.ScannerPages;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.PropertyUtil;
import org.openqa.selenium.JavascriptExecutor;

public class UploadsCS3000Page extends WebDriverBaseTestPage<WebDriverTestPage> {

    @Override
    protected void openPage(PageLocator locator, Object... args){
    }
    PropertyUtil props = ConfigurationManager.getBundle();

    @FindBy(locator = "choose.file.button")
    QAFExtendedWebElement chooseFileButton;    //choose.file.button=id=barcodes

    @FindBy(locator = "get.barcodes.add.to.delivery.trolley")
    QAFExtendedWebElement getBarcodesAddToOrderForDeliveryButton;


    public void uploadTheScannerFile() {
        chooseFileButton.waitForVisible(4000);
        //chooseFileButton.wain(un(1000);
        chooseFileButton.sendKeys("PUBLIC:Valid_ScannerDocSingleProduct.txt");
        //JavascriptExecutor js = (JavascriptExecutor) driver;
        //js.executeScript("document.getElementById('Barcodes').style.display='block';");
        //js.executeScript("document.getElementById('Barcodes').value='src/main/resources/data/scanner.txt';");
        System.out.println("Done");
        getBarcodesAddToOrderForDeliveryButton.click();
    }

    public boolean checkingUploadButtonHasAppearedForDelivery(String buttonName) {
        return getBarcodesAddToOrderForDeliveryButton.getText().equalsIgnoreCase(buttonName);
    }

    public void selectingTheUploadButtonForDelivery(String buttonName) {
        System.out.println("Done2");
        ///getBarcodesAddToOrderForDelivery.click();
    }
}
