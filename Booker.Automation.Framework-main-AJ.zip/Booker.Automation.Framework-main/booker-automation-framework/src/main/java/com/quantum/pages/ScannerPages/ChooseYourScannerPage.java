package com.quantum.pages.ScannerPages;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.PropertyUtil;
import org.openqa.selenium.By;

public class ChooseYourScannerPage extends WebDriverBaseTestPage<WebDriverTestPage> {

    @Override
    protected void openPage(PageLocator locator, Object... args){
    }
    PropertyUtil props = ConfigurationManager.getBundle();

    @FindBy(locator = "radioButton.Scanner.CS3000")
    QAFExtendedWebElement scannerCS3000RadioButton;

    @FindBy(locator = "setupScanner.green.button")
    QAFExtendedWebElement setupScannerButton;

    @FindBy(locator = "continue.green.button")
    QAFExtendedWebElement continueButton;

    public void selectRadioButtonCS3000(){
        scannerCS3000RadioButton.waitForVisible(3000);
        System.out.println(driver.findElement(By.xpath("//*[@id='ScannerSelected' and @value='CS3000']")).isDisplayed());
        System.out.println(scannerCS3000RadioButton.isDisplayed());
        scannerCS3000RadioButton.click();
    }

    public boolean verifyingTheLabelOnSetUpScannerButton(){
        System.out.println(setupScannerButton.getText());
        return setupScannerButton.isDisplayed();
    }

    public boolean verifyingTheLabelOnContinueButton(){
        System.out.println(continueButton.getText());
        return continueButton.isDisplayed();
    }


    public void clickingContinueButton() { continueButton.click();
    }
}
