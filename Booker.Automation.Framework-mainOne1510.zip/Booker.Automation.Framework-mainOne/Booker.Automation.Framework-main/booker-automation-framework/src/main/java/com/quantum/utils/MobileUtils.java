package com.quantum.utils;

import io.appium.java_client.remote.MobilePlatform;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MobileUtils {
    private static final String PLATFORM_NAME_CAPABILITY = "platformName";

    public static boolean isAndroid() {
        return isPlatform(MobilePlatform.ANDROID);
    }

    public static boolean isIOS() {
        return isPlatform(MobilePlatform.IOS);
    }

    private static boolean isPlatform(String platformName) {
        return getPlatformName().equalsIgnoreCase(platformName);
    }

    private static String getPlatformName() {
        return DeviceUtils.getQAFDriver().getCapabilities().getCapability(PLATFORM_NAME_CAPABILITY).toString();
    }

    public static void ocrScroll(String text, String next) {
        Map<String, Object> params = new HashMap<>();
        params.put("content", text);
        params.put("threshold", 95);
        List<String> genericOptions1 = new ArrayList<>();
        genericOptions1.add("natural-language=true");
        params.put("ocr", genericOptions1);
        params.put("scrolling", "scroll");
        params.put("next", next);
        DeviceUtils.getQAFDriver().executeScript("mobile:text:find", params);
    }

    public static void ocrClickByText(String labelText) {
        try {
            Map<String, Object> params = new HashMap<>();
            params.put("label", labelText);
            params.put("timeout", "15");
            params.put("threshold", "90");
            DeviceUtils.getQAFDriver().executeScript("mobile:button-text:click", params);
        } catch (Exception e) {
        }
    }
}
