package com.quantum.pages;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.PropertyUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;

import java.awt.*;
import java.util.List;

public class AlternativeProductModal extends WebDriverBaseTestPage<WebDriverTestPage> {

    @Override
    protected void openPage(PageLocator locator, Object... args) {
    }
    PropertyUtil props = ConfigurationManager.getBundle();

    @FindBy(locator = "//*[@id='alternative-products']/div/div/div[1]/h2")
    private QAFExtendedWebElement modalHeaderAlternativeProduct;

    @FindBy(locator = "//*[@id='alternative-products']/div/div/div[1]/button")
    private QAFExtendedWebElement closeButtonAlternativeProduct;

    @FindBy(locator = "//*[@id='page-content']/section/aside/form/div/p")
    private QAFExtendedWebElement filterByFilterGroupHeader;
    @FindBy(locator = "//*[@id='alternative-products']")
    QAFExtendedWebElement alternativeProductsModalMain;

    public static String listOfProductsFromSearchCss="div.rowMode > div.p-0.p-sm-0.product-list.rowUnGrouped > div";

    public boolean isClickToSeeAlternativesButtonDisplayed(String productCodeExpected) {
        WebElement expectedSearchProduct = searchProducts(productCodeExpected);
        return expectedSearchProduct.isDisplayed();
    }

    public void selectClickToSeeAlternativesButton(String productCodeExpected) {
        WebElement expectedSearchProduct = searchProducts(productCodeExpected);
        expectedSearchProduct.click();
    }
    public boolean isAlternativeProductModalAppeared() {
        modalHeaderAlternativeProduct.waitForVisible(10000);
        System.out.println("Modal" + modalHeaderAlternativeProduct.isDisplayed());
        return modalHeaderAlternativeProduct.isDisplayed();
    }

    public WebElement searchProducts(String productCodeExpected) {
        WebElement searchedProduct = null;
        List<WebElement> listOfProductsFromSearch = driver.findElements(By.cssSelector(listOfProductsFromSearchCss));
        for (WebElement product : listOfProductsFromSearch) {
            String productCode = product.findElement(By.cssSelector("div.product-number>span")).getText();
            if (productCode.contains(productCodeExpected)) {
                System.out.println("Button" + product.findElement(By.id("alternativesBtn")).isDisplayed());
                searchedProduct = product.findElement(By.id("alternativesBtn"));
            }
        }
        return searchedProduct;
    }

    public boolean isCloseButtonOnModalDisplayed() {
        closeButtonAlternativeProduct.waitForVisible(3000);
        return closeButtonAlternativeProduct.isDisplayed();
    }
    public boolean isFilterGroupDisplayed() {
        filterByFilterGroupHeader.waitForVisible(2000);
        return filterByFilterGroupHeader.isDisplayed();
    }

    public void increasingTheCount(){
        List<WebElement> alternativeProductPlusIcon = driver.findElements(By.cssSelector(".rowMode .d-flex .buy-this-product .numbers-only.product-quantity+.plus-minus-icon .fas"));
        if(alternativeProductPlusIcon.isEmpty()){
            System.out.println("No alternative products available to add into trolley");
        } else {System.out.println("We can see " + alternativeProductPlusIcon.size() + "products on the page.");
            alternativeProductPlusIcon.get(0).click();
        }
    }

    public String detailsOfTheSelectedAlternativeProduct(){
        List<WebElement> alternativeProductNumber = driver.findElements(By.cssSelector(".rowMode .d-flex .product-number .codPro"));
        String firstProductNumber = alternativeProductNumber.get(1).getText();
        return firstProductNumber;
    }

    public boolean checkingBackgroundColourOfTheAddedItem() {
        //#A9E0B9 a9e0b9
        String bgInHexValue = null;
        List<WebElement> listOfProductsFromSearch = driver.findElements(By.cssSelector(listOfProductsFromSearchCss));
        String productCodeSelected = detailsOfTheSelectedAlternativeProduct();
        for(WebElement product : listOfProductsFromSearch){
            String productCode = product.findElement(By.cssSelector("div.product-number>span")).getText();
            if (productCode.contains(productCodeSelected)) {
                String bgColourAfterAddingItemsIntoTrolley = product.findElement(By.cssSelector("div.order-item.shopping.row.align-items-center")).getCssValue("background-color");
                bgInHexValue = Color.fromString(bgColourAfterAddingItemsIntoTrolley).asHex();
            }
        }
        if(bgInHexValue.equals("#a9e0b9")){
        System.out.println(bgInHexValue + "Found expected Green color");
        return true;
        }
        else{
            System.out.println(bgInHexValue + ", Found wrong value : ");
            return false;
        }
    }

    public void selectingCloseButtonOnModal() {
        closeButtonAlternativeProduct.click();
    }

    public boolean checkingAlternativeProductsModalDisappeared(){
        System.out.println(alternativeProductsModalMain.getAttribute("class").equalsIgnoreCase("modal p-0") + " The Modal has disappeared.");
        return alternativeProductsModalMain.getAttribute("class").equalsIgnoreCase("modal p-0");
    }
}
