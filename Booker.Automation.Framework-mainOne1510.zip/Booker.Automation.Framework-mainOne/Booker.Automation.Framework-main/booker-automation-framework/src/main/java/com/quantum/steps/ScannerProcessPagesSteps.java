package com.quantum.steps;

import com.qmetry.qaf.automation.step.QAFTestStep;
import com.quantum.utils.ReportUtils;

import java.util.Map;

public class ScannerProcessPagesSteps extends AbstractSteps{

    public static Map<String,String> productDetailsOnScannerPage;

    @QAFTestStep(description="I select the radio button of scanner CS3000 from Choose Your Scanner page")
    public void iSelectTheRadioButtonOfScannerCS3000FromChooseYourScannerPage(){
        chooseYourScannerPage.selectRadioButtonCS3000();
    }

    @QAFTestStep(description="I select the radio button of scanner PX20 from Choose Your Scanner page")
    public void iSelectTheRadioButtonOfScannerPX20FromChooseYourScannerPage(){
        chooseYourScannerPage.selectRadioButtonOpticonPX20();
    }

    @QAFTestStep(description="I should see the continue button and Setup Scanner button have displayed")
    public void iShouldSeeTheContinueButtonAndSetupScannerButtonHaveDisplayed(){
        ReportUtils.logAssert("Checking whether the SetUpScanner appeared on the page",
                chooseYourScannerPage.verifyingTheLabelOnSetUpScannerButton());
        ReportUtils.logAssert("Checking whether the Continue appeared on the page",
                chooseYourScannerPage.verifyingTheLabelOnContinueButton());
    }
    @QAFTestStep(description="I choose Continue Button on Choose Your Scanner page")
    public void iChooseContinueButtonOnChooseYourScannerPage(){

        chooseYourScannerPage.clickingContinueButton();
    }

    @QAFTestStep(description="I upload the scanner file by choosing Choose file button available on the Scanner Uploads page")
    public void iUploadTheScannerFileByChoosingChooseFileButtonAvailableOnTheScannerUploadsPage(){
        scannerUploadsPage.uploadTheScannerFile();
    }

    @QAFTestStep(description="I should see button with label {0}")
    public void iShouldSeeButtonWithLabel(String buttonName){
        ReportUtils.logAssert("Checking the label appeared as expected " + buttonName,
                scannerUploadsPage.checkingScannerUploadButtonHasAppearedForOrder(buttonName));
    }

    @QAFTestStep(description="I click on the {0} button")
    public void iClickOnTheButton(String buttonName){
        scannerUploadsPage.selectingTheScannerUploadButtonForOrder(buttonName);
    }


    @QAFTestStep(description="I click on the Continue button on available on the Important information page")
    public void iClickOnTheContinueButtonOnAvailableOnTheImportantInformationPage(){
        scannerValidateBarcodePage.clickingOnContinueButtonOnImportantInformationPage();
    }


    @QAFTestStep(description="I should see message {0} on the scanner validate barcodes page")
    public void iShouldSeeMessageOnTheScannerValidateBarcodesPage(String message){

        ReportUtils.logAssert("Verifying the successful message",
                scannerValidateBarcodePage.verifyTheSuccessfulMessage().contains(message));
    }

//    @QAFTestStep(description="I should see successful message {0} on scanner validation page")
//    public void iShouldSeeSuccessfulMessageOnScannerValidationPage(String str0){
//        System.out.println("ABC");
//    }

    @QAFTestStep(description="I click on OK button available on the scanner validate barcodes page")
    public void iClickOnOKButtonAvailableOnTheScannerValidateBarcodesPage(){
        scannerValidateBarcodePage.clickOnOKButton();
    }

    @QAFTestStep(description="I should see product code as {0} and product name as {1} in the browse scanned product page")
    public void iShouldSeeProductCodeAsAndProductNameAsInTheBrowseScannedProductPage(String productCode,String productName){
        productDetailsOnScannerPage = scannerValidateBarcodePage.checkingProductDetailsOnBrowseScannedProductsPage();
        System.out.println(productDetailsOnScannerPage);
        ReportUtils.logAssert("verifying product code in product details page", productDetailsOnScannerPage.get("code").equalsIgnoreCase(productCode));
        ReportUtils.logAssert("verifying product name in product details page", productDetailsOnScannerPage.get("description").toLowerCase().trim().contains(productName.toLowerCase().trim()));
    }

    @QAFTestStep(description="I click on Add All to Trolley button")
    public void iClickOnAddAllToTrolleyButton() throws InterruptedException {
        scannerValidateBarcodePage.addingItemsIntoDeliveryTrolley();

    }


    @QAFTestStep(description="I should see order confirmation as {0}")
    public void iShouldSeeOrderConfirmationAs(String str0){
        System.out.println("ABC");
    }


}
