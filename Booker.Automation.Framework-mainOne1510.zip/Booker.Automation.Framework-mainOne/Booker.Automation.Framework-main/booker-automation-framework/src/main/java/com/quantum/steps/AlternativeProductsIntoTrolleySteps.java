package com.quantum.steps;

import com.qmetry.qaf.automation.step.QAFTestStep;
import com.quantum.utils.ReportUtils;

public class AlternativeProductsIntoTrolleySteps extends AbstractSteps{

    @QAFTestStep(description="I should see Click to see alternatives button next to the product {0} on the search product result page")
    public void iShouldSeeClickToSeeAlternativesButtonNextToTheProductOnTheSearchProductResultPage(String mCode){
        ReportUtils.logAssert("Checking alternative button displayed", alternativeProductModal.isClickToSeeAlternativesButtonDisplayed(mCode));
    }

    @QAFTestStep(description="I click on the Click to see alternatives button next to the product {0}")
    public void iClickOnTheClickToSeeAlternativesButtonNextToTheProduct(String mCode){
        alternativeProductModal.selectClickToSeeAlternativesButton(mCode);
    }

    @QAFTestStep(description="A alternative products modal should appear on the page")
    public void aAlternativeProductsModalShouldAppearOnThePage(){
        ReportUtils.logAssert("Checking alternative modal appeared", alternativeProductModal.isAlternativeProductModalAppeared());
    }

    @QAFTestStep(description="I should see a close button on the alternative products modal")
    public void iShouldSeeACloseButtonOnTheAlternativeProductsModal(){
        ReportUtils.logAssert("Checking close button displayed", alternativeProductModal.isCloseButtonOnModalDisplayed());
    }

    @QAFTestStep(description="I should see filter options on the alternative products modal")
    public void iShouldSeeFilterOptionsOnTheAlternativeProductsModal(){
        ReportUtils.logAssert("Checking filter options is visible on the alternative products modal", alternativeProductModal.isFilterGroupDisplayed());
    }

    @QAFTestStep(description="I add first available product into the trolley from the alternative products modal")
    public void iAddFirstAvailableProductIntoTheTrolleyFromTheAlternativeProductsModal() throws InterruptedException {
        alternativeProductModal.increasingTheCount();
        String selectedProductCode = alternativeProductModal.detailsOfTheSelectedAlternativeProduct();
        productDetailsList = myBookerPage.getProductDetails(selectedProductCode);
    }

    @QAFTestStep(description="the background colour of the Add item to trolley area of the selected product should changed to Green colour")
    public void theBackgroundColourOfTheAddItemToTrolleyAreaOfTheSelectedProductShouldChangedToGreenColour(){
        ReportUtils.logAssert("Checking background colour ", alternativeProductModal.checkingBackgroundColourOfTheAddedItem());
    }

    @QAFTestStep(description="I click on the Close button on the alternative products modal")
    public void iClickOnTheCloseButtonOnTheAlternativeProductsModal(){
        alternativeProductModal.selectingCloseButtonOnModal();
    }

    @QAFTestStep(description="The alternative products modal should close and show the product search results page")
    public void theAlternativeProductsModalShouldCloseAndShowTheProductSearchResultsPage(){
        ReportUtils.logAssert("Checking modal closed ", alternativeProductModal.checkingAlternativeProductsModalDisappeared());
    }

    @QAFTestStep(description="I should not see product price with including and excluding VAT")
    public void iShouldNotSeeProductPriceWithIncludingAndExcludingVAT(){
        ReportUtils.logAssert("Verifying the price details did not appeared for the product, which is not available for order", productDetailsPage.checkingProductPriceInformationNotAppeared());
    }

    @QAFTestStep(description="I should see the product details of the product added from the alternative products modal")
    public void iShouldSeeTheProductDetailsOfTheProductAddedFromTheAlternativeProductsModal(){
        String expectedProductCode = productDetailsList.get("code");
        ReportUtils.logAssert("verifying product code in Trolley", trolleyPage.checkingProductCodeAvailableOnTrolley().contains(expectedProductCode));
        String expectedProductDescription = productDetailsList.get("description").trim().toLowerCase();
        ReportUtils.logAssert("verifying product description in Trolley", trolleyPage.checkingProductDescriptionOnTrolley().trim().toLowerCase().contains(expectedProductDescription.trim().toLowerCase()));
        String expectedProductPrice = productDetailsList.get("price");
        String actualProductPrice = trolleyPage.getTotalGuidedPriceExVAT();  //.replace("£","");
        ReportUtils.logAssert("verifying product price in Trolley", actualProductPrice.equalsIgnoreCase(expectedProductPrice));
    }

}
