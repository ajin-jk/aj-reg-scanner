package com.quantum.pages;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.PropertyUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;


public class TrolleyPage extends WebDriverBaseTestPage<WebDriverTestPage> {
    @Override
    protected void openPage(PageLocator locator, Object... args) {
    }
    PropertyUtil props = ConfigurationManager.getBundle();

    @FindBy(locator = "#removeAllFromTrolleyForm>button")
    private QAFExtendedWebElement removeAllButton;

    @FindBy(locator = ".remove-all-continue-button")
    private QAFExtendedWebElement removeAllContinueButton;

    @FindBy(locator = ".buttons > .grey-btn")
    private QAFExtendedWebElement removeAllCancelButton;

    @FindBy(locator = ".empty-trolley>div")
    private QAFExtendedWebElement emptyTrolleyWarningMessage;

    @FindBy(locator = "#booker_trolley_first_aside > div > div.card-body.pb-0 > div > div:nth-child(1) > span:nth-child(2)")
    private QAFExtendedWebElement branchStockedPriceExVAT;

    @FindBy(locator = "#booker_trolley_first_aside  button.btn.green-btn.mb-2")
    private QAFExtendedWebElement proceedToCheckoutButton;

    @FindBy(locator = "#booker_trolley_first_aside > div > div.card-body.pb-0 > p > span")
    private QAFExtendedWebElement noOfCases;

    @FindBy(locator = "#booker_trolley_first_aside > div > div.card-body.pb-0 > div > div.d-flex.total > span:nth-child(2)")
    private QAFExtendedWebElement totalGuidedPriceExVAT;

    @FindBy(locator = "#booker_trolley_first_aside > div > div.card-body.pb-0 > div > div.d-flex.mb-4 > span:nth-child(2)")
    private QAFExtendedWebElement totalGuidedPriceIncludingVAT;

    @FindBy(locator = "//*[@id='booker_trolley_first_main']/div[3]/div/div/div[1]/div/div[1]/span")
    private QAFExtendedWebElement firstElementCode;

    @FindBy(locator = "//*[@id='booker_trolley_first_main']/div[3]/div/div/div[2]/div[1]/div[2]/p[1]")
    private QAFExtendedWebElement firstElementDesc;

    @FindBy(locator = ".rowMode .d-flex .buy-this-product .numbers-only.product-quantity+.plus-minus-icon")
    private QAFExtendedWebElement firstElementPlusIcon;

    @FindBy(locator = "//*[@id='booker_trolley_first_main']/p")
    private QAFExtendedWebElement minOrderWarningMessage;

    //
    public void clickRemoveAll(){
        removeAllButton.waitForVisible(60000);
        removeAllButton.click();
    }

    public void clickRemoveAllContinueButton(){
        removeAllContinueButton.click();
    }

    public void clickCancelContinueButton(){
        removeAllContinueButton.click();
    }

    public String getEmptyTrolleyWarningMessage(){
        emptyTrolleyWarningMessage.waitForVisible(30000);
        return emptyTrolleyWarningMessage.getText();
    }

    public boolean isContinueButtonDisplayed(){
        try {
            return removeAllContinueButton.isDisplayed();
        }
        catch (Exception e){
            return false;
        }
    }

    public boolean isCancelButtonDisplayed(){
        try {
            return removeAllCancelButton.isDisplayed();
        }
        catch (Exception e){
            return false;
        }
    }

    public String getBranchStockedPrice(){
        branchStockedPriceExVAT.waitForVisible(5000);
        return branchStockedPriceExVAT.getText();
    }

    public String getNoOfCases(){
        noOfCases.waitForVisible(5000);
        return noOfCases.getText();
    }

    public String getTotalGuidedPriceExVAT(){
        totalGuidedPriceExVAT.waitForVisible(5000);
        return totalGuidedPriceExVAT.getText();
    }

    public String getTotalGuidedPriceIncludingVAT(){
        totalGuidedPriceIncludingVAT.waitForVisible(5000);
        return totalGuidedPriceIncludingVAT.getText();
    }

    public void clickProceedToCheckoutButton(){
        proceedToCheckoutButton.waitForVisible(5000);
        proceedToCheckoutButton.click();
    }

    public String checkingProductCodeAvailableOnTrolley() {
        firstElementCode.waitForVisible(2000);
        return firstElementCode.getText();
    }

    public String checkingProductDescriptionOnTrolley() {
        firstElementDesc.waitForVisible(1000);
        return firstElementDesc.getText();
    }

    public boolean checkingMinimumOrderWarningMessage() {
        System.out.println(minOrderWarningMessage.getText());
        System.out.println(minOrderWarningMessage.getText().contains("Your total order value is below the minimum amount of £100.00."));
        return minOrderWarningMessage.getText().contains("Your total order value is below the minimum amount of £100.00");
    }
    public void increasingTheCount(String pCode){
        firstElementPlusIcon.waitForVisible(10000);
        for (int i = 0; i < 10; i++) {
            //firstElementInputBox.waitForVisible(5000);
            firstElementPlusIcon.click();
        }
    }

}
