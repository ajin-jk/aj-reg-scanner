package com.quantum.pages;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.PropertyUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class MyPreviousInvoicesPage extends WebDriverBaseTestPage<WebDriverTestPage> {
    @Override
    protected void openPage(PageLocator locator, Object... args) {
    }
    PropertyUtil props = ConfigurationManager.getBundle();

    @FindBy(locator = "//*[@id='booker_Previous_Invoices']/div[1]/div/span")
    private QAFExtendedWebElement validationMessage;
    @FindBy(locator = "//*[@id='booker_Previous_Invoices']/div[1]/table/thead/tr/th[1]")
    private QAFExtendedWebElement tableHeaderDate;

    @FindBy(locator = ".ellipsis")
    private QAFExtendedWebElement invoiceNumberClass;

    @FindBy(locator = "//*[@id='booker_Previous_Invoices']/div[1]/table")
    private QAFExtendedWebElement tableXpath;

    public boolean checkingValidationMessageDisplayedOnThePage() throws InterruptedException {
        Thread.sleep(5000);
        if(validationMessage.isPresent()){
            return false;
        }else {
            return true;
        }
    }
    public boolean checkingThePreviousInvoicesSummaryTableDisplayed() {
        tableHeaderDate.waitForVisible(1000);
        return tableHeaderDate.isDisplayed();
    }

    public boolean checkingTheInvoiceNumberAppearedOnTheTable(String invoiceNo) {
        List<WebElement> invoiceNumbersOnTable = driver.findElements(By.cssSelector(".ellipsis"));
        Boolean check = false;
        for (WebElement cell : invoiceNumbersOnTable) {
            if (cell.getText().equals(invoiceNo)) {
                check = true;
                break;
            }
        }
        return check;
    }


    public void clickingOnInvoiceNumberProvided(String invoiceNo) {
        WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(10));
        List<WebElement> invoiceNumbersOnTable = driver.findElements(By.cssSelector(".ellipsis"));
        for (WebElement cell : invoiceNumbersOnTable) {
            if (cell.getText().equals(invoiceNo)) {
                wait1.until(ExpectedConditions.elementToBeClickable(cell));
                break;
            }
        }
    }
}



//// Get all rows of the table - Dynamic table
//List<WebElement> rows = tableXpath.findElements(By.tagName("tr"));
//boolean valueFound = false;
//// Iterate through each row
//        for (WebElement row : rows) {
//// Get all cells in the current row
//List<WebElement> cells = row.findElements(By.tagName("td"));
//
//// Iterate through each cell
//            for (WebElement cell : cells) {
//        if (cell.getText().equals(invoiceNo)) {
//valueFound = true;
//        break;
//        }
//        }
//        }
//        System.out.println(valueFound + "Available");