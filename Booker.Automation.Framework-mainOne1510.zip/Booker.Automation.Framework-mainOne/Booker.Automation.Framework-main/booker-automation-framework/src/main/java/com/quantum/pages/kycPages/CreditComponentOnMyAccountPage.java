package com.quantum.pages.kycPages;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;

import java.util.*;

public class CreditComponentOnMyAccountPage extends WebDriverBaseTestPage<WebDriverTestPage> {
    //We have more scenarios relating to the credit component, so created separate page object model for this component
    @Override
    protected void openPage(PageLocator pageLocator, Object... objects) {

    }
    @FindBy(locator = "//*[@id='credit-account']/div[1]/h4")
    private QAFExtendedWebElement creditComponentHeader;

    @FindBy(locator = "//*[@id='credit-account']/div[2]/a")
    private QAFExtendedWebElement applyForCreditButton;

    @FindBy(locator = ".container[data-component-context]")
    private QAFExtendedWebElement statusCompletionBarContainer;

    //public Map<Integer, Map<String,String>> statusBarDetails;

    //Credit component header
    public Boolean checkingCreditComponentOnMyAccountPage() {
        //to perform Scroll on application using Selenium
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,450)", "");
        creditComponentHeader.waitForVisible(2000);
        return creditComponentHeader.isDisplayed();
    }

    public String creditComponentHeader(){
        return creditComponentHeader.getText();
    }

    public void clickingOnApplyForCreditButton() {
        applyForCreditButton.click();
    }

    public boolean isStatusBarAppeared(){
        statusCompletionBarContainer.waitForVisible(2000);
        return statusCompletionBarContainer.isDisplayed();
    }

    public Map<Integer, Map<String, String>> statusCompletionBarOnCreditComponent() throws Exception {
        Map<Integer, Map<String, String>> statusBarDetails = new HashMap<Integer, Map<String, String>>();
        int position = 1;

        //checking process step and position number
        List<WebElement> kycProcessSteps = statusCompletionBarContainer.findElements(By.cssSelector("[data-component='indicator-step']"));
        for(WebElement step : kycProcessSteps){

            String kycStepTitle = step.getAttribute("data-prop--title");
            WebElement kycStepNumber = step.findElement(By.cssSelector(".kyc-indicator-step---number"));
            String stepNumber = kycStepNumber.getText().trim();

            //checking background colour
            String bgColor = backgroundColor(kycStepNumber);

            // Check if the step is square
            boolean isSquare = "true".equals(step.getAttribute("data-prop--square"));
            //checking shape of the steps
            String shape = "Not identified";
            if (isSquare){
                shape="Square";
            } else{
                shape="Circle";
            }
            Map<String, String> detailsPosition  = new HashMap<>();

            detailsPosition.put("processStepName", kycStepTitle);
            detailsPosition.put("stepNumber", stepNumber);
            detailsPosition.put("shapeProcess", shape);
            detailsPosition.put("colourProcess", bgColor);

            statusBarDetails.put(position, detailsPosition);
            position++;
        }
        return statusBarDetails;
    }

    public void printAll(Map<Integer, Map<String, String>> creditComponentStatusCompletionBar){
        // Printing all values from the map
        for (Map.Entry<Integer, Map<String, String>> outerEntry : creditComponentStatusCompletionBar.entrySet()) {
            Integer positionStep = outerEntry.getKey();
            Map<String, String> innerMap = outerEntry.getValue();

            System.out.println("Position: " + positionStep);

            // Iterate through the inner map to print details
            for (Map.Entry<String, String> innerEntry : innerMap.entrySet()) {
                String detailKey = innerEntry.getKey();
                String detailValue = innerEntry.getValue();
                System.out.println(detailKey + ": " + detailValue);
            }
            System.out.println("//////////"); // Blank line between different positions
        }
    }

    public Map<String, String> stepDetails(int positionToDisplay) throws Exception {
        Map<Integer, Map<String,String>> statusBarDetails = statusCompletionBarOnCreditComponent();
        Map<String, String> detailsForPosition = null;
        if (statusBarDetails.containsKey(positionToDisplay)) {
            //detailsForPosition = statusBarDetails.get(positionToDisplay);
            return statusBarDetails.get(positionToDisplay);
        } else {
            System.out.println("Position " + positionToDisplay + " not found.");
        }
        return detailsForPosition;
    }

    public String backgroundColor(WebElement stepNumberEle) throws Exception {
        String expectedBgColor = null;
        String backgroundColor = stepNumberEle.getCssValue("background-color");
        String actualhexColor = Color.fromString(backgroundColor).asHex();

        boolean isActive = stepNumberEle.getAttribute("class").contains("kyc-indicator-step---active ");
        if (isActive) {
            expectedBgColor = "#253494";
            System.out.println("Background color should be dark blue: " + actualhexColor.equals(expectedBgColor));
        } else {
            expectedBgColor = "#dededc";
            System.out.println("Background color should be Light grey: " + actualhexColor.equals(expectedBgColor));
        }
        return actualhexColor;
    }


}

