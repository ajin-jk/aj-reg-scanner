package com.quantum.steps;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.quantum.utils.ReportUtils;

public class TrolleyPageSteps extends AbstractSteps {

    @QAFTestStep(description="I should see Cancel and Remove all buttons are displayed")
    public void iShouldSeeCancelAndRemoveAllButtonsAreDisplayed(){
        ReportUtils.logAssert("verifying Continue button is displayed", trolleyPage.isContinueButtonDisplayed());
        ReportUtils.logAssert("verifying Cancel button is displayed", trolleyPage.isCancelButtonDisplayed());
    }

    @QAFTestStep(description="I click on Remove all button to remove all products from Trolley")
    public void iClickOnRemoveAllButtonToRemoveAllProductsFromTrolley(){
        trolleyPage.clickRemoveAll();
    }

    @QAFTestStep(description="I should see a message in trolley as {0}")
    public void iShouldSeeAMessageInTrolleyAs(String message){
        ReportUtils.logAssert("verifying warning message for empty trolley", trolleyPage.getEmptyTrolleyWarningMessage().toLowerCase().trim().contains(message.toLowerCase().trim()));
    }

    @QAFTestStep(description="I click on Continue button to remove all products")
    public void iClickOnContinueButtonToRemoveAllProducts(){
        trolleyPage.clickRemoveAllContinueButton();
    }


    @QAFTestStep(description="I should see order item price and quantity in the shopping list")
    public void iShouldSeeOrderItemPriceAndQuantityInTheShoppingList(){
        String stockedPrice = trolleyPage.getBranchStockedPrice().replace("£","");
        String deliveryProductPrice = ConfigurationManager.getBundle().getProperty("priceExcludingVat").toString();
        System.out.println(Double.parseDouble(stockedPrice) + " = " + Double.parseDouble(deliveryProductPrice));
        ReportUtils.logAssert("verifying branch stocked price in trolley", Double.parseDouble(stockedPrice)==Double.parseDouble(deliveryProductPrice));
    }


    @QAFTestStep(description="I should see number of cases as {0} in the checkout summary")
    public void iShouldSeeNumberOfCasesAsInTheCheckoutSummary(String cases){
        ReportUtils.logAssert("verifying number of cases in trolley", trolleyPage.getNoOfCases().contains(cases));
    }

    @QAFTestStep(description="I should see Excluding VAT Total Guide Price in the checkout summary")
    public void iShouldSeeExcludingVATTotalGuidePriceInTheCheckoutSummary(){
        String guidedPriceExVAT = trolleyPage.getTotalGuidedPriceExVAT().replace("£","");
        System.out.println(Double.parseDouble(guidedPriceExVAT) + " = " + Double.parseDouble(ConfigurationManager.getBundle().getProperty("priceExcludingVat").toString()));
        ReportUtils.logAssert("verifying total guided price excluding VAT in trolley", Double.parseDouble(guidedPriceExVAT)==(Double.parseDouble(ConfigurationManager.getBundle().getProperty("priceExcludingVat").toString())));
    }

    @QAFTestStep(description="I should see Including VAT Total Guide Price in the checkout summary")
    public void iShouldSeeIncludingVATTotalGuidePriceInTheCheckoutSummary(){
        String guidedPriceIncludingVAT = trolleyPage.getTotalGuidedPriceIncludingVAT().replace("£","");
        ReportUtils.logAssert("verifying total guided price excluding VAT in trolley", Double.parseDouble(guidedPriceIncludingVAT)==Double.parseDouble(ConfigurationManager.getBundle().getProperty("priceIncludingVat").toString()));
    }

    @QAFTestStep(description="I click on proceed to checkout")
    public void iClickOnProceedToCheckout(){
        trolleyPage.clickProceedToCheckoutButton();
    }

    @QAFTestStep(description="I should see product code as {0} and product name as {1} in the booker trolley page")
    public void iShouldSeeProductCodeAsAndProductNameAsInTheBookerTrolleyPage(String productCode,String productDescription){
        ReportUtils.logAssert("verifying product code in Trolley", trolleyPage.checkingProductCodeAvailableOnTrolley().contains(productCode));
        ReportUtils.logAssert("verifying product description in Trolley", trolleyPage.checkingProductDescriptionOnTrolley().trim().toLowerCase().contains(productDescription.trim().toLowerCase()));
    }

    @QAFTestStep(description="I should see a warning message for the minimum order")
    public void iShouldSeeAWarningMessageForTheMinimumOrder(){
        ReportUtils.logAssert("verifying minimum order warning message", trolleyPage.checkingMinimumOrderWarningMessage());
    }

    @QAFTestStep(description="I increase count of the product {0} to reach minimum order")
    public void iIncreaseCountOfTheProductToReachMinimumOrder(String pCode){
        trolleyPage.increasingTheCount(pCode);
    }
}
