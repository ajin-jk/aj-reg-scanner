package com.quantum.steps;

import com.qmetry.qaf.automation.step.QAFTestStep;
import com.quantum.utils.ReportUtils;

public class MyPreviousInvoicesSteps extends AbstractSteps{
    @QAFTestStep(description="I should not see validation error message on the Previous Invoices Summary page")
    public void iShouldNotSeeValidationErrorMessageOnThePreviousInvoicesSummaryPage() throws InterruptedException {
        ReportUtils.logAssert("Checking my previous invoices and statement component displayed",
                myPreviousInvoicesPage.checkingValidationMessageDisplayedOnThePage());
    }
    @QAFTestStep(description="I should see table for the Previous Invoices Summary")
    public void iShouldSeeTableForThePreviousInvoicesSummary(){
        ReportUtils.logAssert("Checking my previous invoices and statement component displayed", myPreviousInvoicesPage.checkingThePreviousInvoicesSummaryTableDisplayed());
    }

    @QAFTestStep(description="I should see invoice number as {0} within the table")
    public void iShouldSeeInvoiceNumberAsWithinTheTable(String invoiceNo){
        myPreviousInvoicesPage.checkingTheInvoiceNumberAppearedOnTheTable(invoiceNo);
    }

    @QAFTestStep(description="I click on the invoice number {0}")
    public void iClickOnTheInvoiceNumber(String invoiceNo){
        myPreviousInvoicesPage.clickingOnInvoiceNumberProvided(invoiceNo);
    }

    @QAFTestStep(description="I should navigate to the Detailed Invoice Summary page")
    public void iShouldNavigateToTheDetailedInvoiceSummaryPage(){

    }

    @QAFTestStep(description="I should see {0} on the Detailed Invoice Summary page")
    public void iShouldSeeOnTheDetailedInvoiceSummaryPage(String invoiceNo){

    }

}
