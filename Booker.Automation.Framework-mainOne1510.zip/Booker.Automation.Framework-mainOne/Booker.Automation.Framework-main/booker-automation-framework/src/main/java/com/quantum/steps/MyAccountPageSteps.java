package com.quantum.steps;

import com.qmetry.qaf.automation.step.QAFTestStep;
import com.quantum.utils.ReportUtils;

public class MyAccountPageSteps extends AbstractSteps{
    @QAFTestStep(description="I should able to see my previous invoices and statement component on the my account page")
    public void iShouldAbleToSeeMyPreviousInvoicesAndStatementComponentOnTheMyAccountPage(){
        ReportUtils.logAssert("Checking my previous invoices and statement component displayed", myAccountPage.checkingMyPreviousInvoicesAndStatementComponentDisplayed());
    }
    @QAFTestStep(description="I should see My invoices button on the my previous invoices and statement component")
    public void iShouldSeeMyInvoicesButtonOnTheMyPreviousInvoicesAndStatementComponent(){
        ReportUtils.logAssert("Checking my previous invoices and statement component displayed", myAccountPage.checkingMyInvoicesButtonDisplayed());
    }
    @QAFTestStep(description="I click on the My invoices button")
    public void iClickOnTheMyInvoicesButton(){
        myAccountPage.clickingOnMyInvoiceButton();
    }
}
