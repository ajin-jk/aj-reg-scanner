package com.quantum.steps;

import com.qmetry.qaf.automation.step.QAFTestStep;
import com.quantum.utils.ReportUtils;

import java.util.Map;

public class CreditComponentVerificationSteps extends AbstractSteps{




//    @QAFTestStep(description="checking statusBar")
//    public void checkingStatusBar() throws Exception {
//        creditComponentStatusCompletionBar = creditComponentOnMyAccountPage.statusCompletionBarOnCreditComponent();
//    }
//    @QAFTestStep(description="print Details")
//    public void printDetails() throws Exception {
//        creditComponentOnMyAccountPage.printAll(creditComponentStatusCompletionBar);
//    }
    @QAFTestStep(description="I should see {0} as header of the credit component")
    public void iShouldSeeAsHeaderOfTheCreditComponent(String creditHeader){
        ReportUtils.logAssert("verifying Credit component Header", creditComponentOnMyAccountPage.creditComponentHeader().equals(creditHeader));
    }

    @QAFTestStep(description="I should see status bar on credit component page")
    public void iShouldSeeStatusBarOnCreditComponentPage() throws Exception {
        ReportUtils.logAssert("verifying Credit component Header", creditComponentOnMyAccountPage.isStatusBarAppeared());
        //creditComponentOnMyAccountPage.statusCompletionBarOnCreditComponent();
    }
    @QAFTestStep(description="I should see first Kyc process step name as {0} shape as {1} and colour as {2}")
    public void iShouldSeeFirstKycProcessStepNameAsShapeAsAndColourAs(String stepName,String stepShape,String stepColour) throws Exception {
        int positionToDisplay = 1;
        creditComponentStatusCompletionBar = creditComponentOnMyAccountPage.stepDetails(positionToDisplay);
        // Print the details for the specific position (for debugging)
        System.out.println("Position " + positionToDisplay + " Details:");
        for (Map.Entry<String, String> entry : creditComponentStatusCompletionBar.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }

    @QAFTestStep(description="I should see second Kyc process step name as {0} shape as {1} and colour as {2}")
    public void iShouldSeeSecondKycProcessStepNameAsShapeAsAndColourAs(String stepName,String stepShape,String stepColour){

    }

    @QAFTestStep(description="I should see third Kyc process step name as {0} shape as {1} and colour as {2}")
    public void iShouldSeeThirdKycProcessStepNameAsShapeAsAndColourAs(String stepName,String stepShape,String stepColour){

    }

    @QAFTestStep(description="I should see Kyc process step name as {0} shape as {1} and colour as {2}")
    public void iShouldSeeKycProcessStepNameAsShapeAsAndColourAs(String stepName,String stepShape,String stepColour){


    }

    @QAFTestStep(description="I should see forth Kyc process step name as {0} shape as {1} and colour as {2}")
    public void iShouldSeeForthKycProcessStepNameAsShapeAsAndColourAs(String stepName,String stepShape,String stepColour){

    }

    @QAFTestStep(description="I should see fifth Kyc process step name as {0} shape as {1} and colour as {2}")
    public void iShouldSeeFifthKycProcessStepNameAsShapeAsAndColourAs(String stepName,String stepShape,String stepColour){

    }

    @QAFTestStep(description="I should see Appy for Credit button on the credit component")
    public void iShouldSeeAppyForCreditButtonOnTheCreditComponent(){

    }

}
