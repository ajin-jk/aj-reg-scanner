package com.quantum.pages;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.PropertyUtil;

public class MyAccountPage extends WebDriverBaseTestPage<WebDriverTestPage> {
    @Override
    protected void openPage(PageLocator locator, Object... args) {
    }
    PropertyUtil props = ConfigurationManager.getBundle();

    @FindBy(locator = "//*[@id='previous-invoices-statements']/div[1]/h4")
    private QAFExtendedWebElement previousInvoicesStatementsComponentHeader;

    @FindBy(locator = "//*[@id='my-invoices']/div[2]/a")
    private QAFExtendedWebElement myInvoicesButton;

    public boolean checkingMyPreviousInvoicesAndStatementComponentDisplayed() {
        previousInvoicesStatementsComponentHeader.waitForVisible(2000);
        return previousInvoicesStatementsComponentHeader.isDisplayed();
    }

    public boolean checkingMyInvoicesButtonDisplayed() {
        myInvoicesButton.waitForVisible(1000);
        return myInvoicesButton.isDisplayed();
    }

    public void clickingOnMyInvoiceButton() {
        myInvoicesButton.click();
    }
}
