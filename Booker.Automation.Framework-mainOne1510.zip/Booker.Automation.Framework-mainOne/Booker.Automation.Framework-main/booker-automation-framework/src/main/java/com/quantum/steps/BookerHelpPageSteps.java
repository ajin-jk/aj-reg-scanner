package com.quantum.steps;

import com.qmetry.qaf.automation.step.QAFTestStep;
import com.quantum.utils.ReportUtils;

public class BookerHelpPageSteps extends AbstractSteps {


    @QAFTestStep(description="I should be redirected to Booker Help page")
    public void iShouldBeRedirectedToBookerHelpPage(){
    	ReportUtils.logAssert("verifying Booker Help Page is loaded", bookerHelpPage.isBookerHelpPageLoaded());
    }
    
    @QAFTestStep(description="I should see booker page header as {0}")
    public void iShouldSeeBookerPageHeaderAs(String headerText){
    	ReportUtils.logAssert("verifying Booker Help Page header text", bookerHelpPage.getHeaderText().equalsIgnoreCase(headerText));
    }

    @QAFTestStep(description="I should see Return to Home button")
    public void iSholdSeeReturnToHomeButton(){
    	ReportUtils.logAssert("verifying return to home button exists", bookerHelpPage.isReturnHomeButtonExists());
    }

    @QAFTestStep(description="I click on Return to Home button")
    public void iClickOnReturnToHomeButton(){
    	bookerHelpPage.clickReturnHome();
    }
}
