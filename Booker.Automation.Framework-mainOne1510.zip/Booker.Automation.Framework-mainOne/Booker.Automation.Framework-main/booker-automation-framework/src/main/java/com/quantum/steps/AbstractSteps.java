package com.quantum.steps;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.util.PropertyUtil;
import com.quantum.pages.*;
import com.quantum.pages.ScannerPages.*;
import com.quantum.pages.kycPages.*;
import com.quantum.pages.registrationPages.CreateAnAccountPage;
import com.quantum.pages.registrationPages.WhatIsYourBusinessPage;

import java.util.Map;

public class AbstractSteps {
	PropertyUtil props = ConfigurationManager.getBundle();
	public static Map<String,String> productDetailsList;
	public static Map<String, String> creditComponentStatusCompletionBar;

	LoginPage loginPage;
	 BookerHomePage bookerHomePage;
	 BookerHelpPage bookerHelpPage;

	 MyBookerPage myBookerPage;
	MyAccountPage myAccountPage;

	 TrolleyPage trolleyPage;
	 ProductDetailsPage productDetailsPage;
	 AdditionalInformationPage additionalInformationPage;
	 OrderSummaryPage orderSummaryPage;
	 PaymentPage paymentPage;
	 OrderConfirmationPage orderConfirmationPage;
	 WhatIsYourBusinessPage whatIsYourBusinessPage;
	CreateAnAccountPage createAnAccountPage;
	ChooseYourScannerPage chooseYourScannerPage;
	ScannerUploadsPage scannerUploadsPage;
	ScannerValidateBarcodePage scannerValidateBarcodePage;
	KycFormPage kycFormPage;
	CreditComponentOnMyAccountPage creditComponentOnMyAccountPage;
	TnCPage tnCPage;
	KycDocumentSignPage kycDocumentSignPage;
	KycStageCompletionPage kycStageCompletionPage;
	MyPreviousInvoicesPage myPreviousInvoicesPage;
	AlternativeProductModal alternativeProductModal;

	 
	 public AbstractSteps() {
		 loginPage = new LoginPage();
		 bookerHomePage = new BookerHomePage();
		 bookerHelpPage = new BookerHelpPage();
		 myBookerPage = new MyBookerPage();
		 trolleyPage = new TrolleyPage();
		 productDetailsPage = new ProductDetailsPage();
		 additionalInformationPage= new AdditionalInformationPage();
		 orderSummaryPage = new OrderSummaryPage();
		 paymentPage = new PaymentPage();
		 orderConfirmationPage = new OrderConfirmationPage();
		 whatIsYourBusinessPage = new WhatIsYourBusinessPage();
		 createAnAccountPage = new CreateAnAccountPage();
		 chooseYourScannerPage = new ChooseYourScannerPage();
		 scannerUploadsPage = new ScannerUploadsPage();
		 scannerValidateBarcodePage = new ScannerValidateBarcodePage();
		 kycFormPage = new KycFormPage();
		 creditComponentOnMyAccountPage = new CreditComponentOnMyAccountPage();
		 tnCPage = new TnCPage();
		 kycDocumentSignPage = new KycDocumentSignPage();
		 kycStageCompletionPage = new KycStageCompletionPage();
		 myAccountPage = new MyAccountPage();
		 myPreviousInvoicesPage = new MyPreviousInvoicesPage();
		 alternativeProductModal = new AlternativeProductModal();
	}
}
