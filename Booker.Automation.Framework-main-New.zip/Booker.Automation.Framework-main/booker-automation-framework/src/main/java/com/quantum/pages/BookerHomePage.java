package com.quantum.pages;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.PropertyUtil;
import static com.quantum.utils.MobileUtils.*;

import com.quantum.utils.DeviceUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;

import java.util.HashMap;
import java.util.Map;

public class BookerHomePage extends WebDriverBaseTestPage<WebDriverTestPage>{

	PropertyUtil props = ConfigurationManager.getBundle();

	@Override
	protected void openPage(PageLocator locator, Object... args) {
	}
	@FindBy(locator = "home.customer.number")
	private QAFExtendedWebElement customerNumber;
	
	@FindBy(locator = "home.login.button")
	private QAFExtendedWebElement loginButton;
	
	
	@FindBy(locator = "home.login.validation.message")
	private QAFExtendedWebElement customerNumberValidationMessage;
	
	@FindBy(locator = "#CybotCookiebotDialogBodyLevelButtonLevelOptinAllowAll")
	private QAFExtendedWebElement cookiesPopup;
	
	@FindBy(locator = "home.logo.image")
	private QAFExtendedWebElement homePageLogo;

	@FindBy(locator = "home.register.button")
	private QAFExtendedWebElement homeRegisterButton;

	public void enterCustomerNumber(String custNumber) {
		customerNumber.waitForVisible(5000);
		customerNumber.clear();
		customerNumber.click();
		customerNumber.sendKeys(custNumber);
	}
	
	public void clickLogin() {
		loginButton.click();
	}
	
	public String getCustomerValidationMessage() {
		return customerNumberValidationMessage.getText();
	}

	public void allowCookies() {

		//----

		Cookie xMappingCookie = driver.manage().getCookieNamed("X-Mapping-njpjhfpc");

		if (xMappingCookie != null) {
			// Print current value of 'x-mapping'
			System.out.println("Current x-mapping cookie value: " + xMappingCookie.getValue());

			// Determine which server is currently being used and update if necessary
			if (!xMappingCookie.getValue().equals("5935520A0516035517081179479909D9")) {
				// Update the cookie with the desired server mapping
				Cookie updatedCookie = new Cookie("X-Mapping-njpjhfpc", "5935520A0516035517081179479909D9");
				driver.manage().deleteCookie(xMappingCookie); // Delete old cookie
				driver.manage().addCookie(updatedCookie); // Add updated cookie

				// Refresh the page or navigate to enforce the change
				driver.navigate().refresh();

				System.out.println("Updated x-mapping cookie to: " + updatedCookie.getValue());
			} else {
				System.out.println("Already using the desired server mapping.");
			}
		} else {
			System.out.println("x-mapping cookie not found. Cannot determine current server.");
		}

		//----

		try {
			if(isAndroid()){
				ocrClickByText("Allow all cookies");
			} else if (isIOS()) {
				ocrClickByText("Allow all cookies");
			} else{
				cookiesPopup.waitForVisible(3000);
				cookiesPopup.click();
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}



	}
	
	public void clearCustomerNumber() {
		customerNumber.waitForVisible(5000);
		customerNumber.clear();
		customerNumber.sendKeys("");
	}

	public boolean isCustomerFieldExists() {
		try {
			return customerNumber.isDisplayed();
		} catch (Exception e) {
			return false;
		}		
	}
	
	public boolean isHomePageLogoDisplayed() {
		try {
			return homePageLogo.isDisplayed();
		} catch (Exception e) {
			return false;
		}
	}

	public void clickRegisterButton(){
		homeRegisterButton.waitForVisible(6000);
		homeRegisterButton.click();
	}


	
}
