package com.quantum.steps;

import com.qmetry.qaf.automation.step.QAFTestStep;
import com.quantum.utils.ReportUtils;

import java.util.List;
import java.util.Map;

public class MyBookerPageSteps extends AbstractSteps {
    @QAFTestStep(description="I should see delivery option background color as green")
    public void iShouldSeeDeliveryOptionBackgroundColorAsGreen(){
        String deliveryOptionBackGroundColor = myBookerPage.getBackGroundColour("delivery");
        ReportUtils.logAssert("verifying back ground color of delivery option", deliveryOptionBackGroundColor.contains("green"));
    }


    @QAFTestStep(description="I click on click and collect option")
    public void iClickOnClickAndCollectOption(){
        myBookerPage.clickClickAndCollectButton();
    }


    @QAFTestStep(description="I should see click and collect option background color as orange")
    public void iShouldSeeClickAndCollectOptionBackgroundColorAsOrange(){
        String clickAndCollectOptionBackGroundColor = myBookerPage.getBackGroundColour("clickAndCollect");
        ReportUtils.logAssert("verifying back ground color of click and collect option", clickAndCollectOptionBackGroundColor.contains("orange"));
    }


    @QAFTestStep(description="I click on Trolley button")
    public void iClickOnTrolleyButton() throws InterruptedException {
        myBookerPage.clickTrolleyButton();
        Thread.sleep(5000);
    }

    @QAFTestStep(description="I should see the delivery options as {0} for the customer {1}")
    public void iShouldSeeDeliveryOptionAsAndClickAndCollectOptionForTheCustomer(String deliveryOption,String customerNumber){
        if (deliveryOption.equalsIgnoreCase("0")){
            String deliveryOptionBackGroundColor = myBookerPage.getBackGroundColour("clickAndCollect");
            ReportUtils.logAssert("verifying back ground color of click and collect option", deliveryOptionBackGroundColor.contains("orange"));
        } else if (deliveryOption.equalsIgnoreCase("1")) {
            String deliveryOptionBackGroundColor = myBookerPage.getBackGroundColour("delivery");
            ReportUtils.logAssert("verifying back ground color of delivery option", deliveryOptionBackGroundColor.contains("green"));
        }
    }

    @QAFTestStep(description="I search for the product {0}")
    public void iSearchForTheProduct(String productCode) throws InterruptedException {
        myBookerPage.searchForProduct(productCode);
        productDetailsList = myBookerPage.getProductDetails(productCode);
    }

    @QAFTestStep(description="I should be able to see the product {0} in the search results")
    public void iShouldBeAbleToSeeTheProductInTheSearchResults(String productDesc){
        ReportUtils.logAssert("verifying product description from search results of product", productDetailsList.get("description").toLowerCase().trim().contains(productDesc.trim().toLowerCase()));
    }

    @QAFTestStep(description="I should see product price as excluding VAT with default selection as zero items")
    public void iShouldSeeProductPriceAsExcludingVATWithDefaultSelectionAsZeroItems(){
        Double productPrice = Double.parseDouble(productDetailsList.get("price").replace("£",""));
        ReportUtils.logAssert("verifying product price is greater than zero from search results of product", productPrice>=0);
        ReportUtils.logAssert("verifying default selected quantity as zero ", productDetailsList.get("quantity").equals("0"));
    }

    @QAFTestStep(description="I select the product {0}")
    public void iSelectTheProduct(String productCode){

        myBookerPage.selectProductFromSearchResults(productCode);
    }

    @QAFTestStep(description="I click on My Account Link")
    public void iClickOnMyAccountLink(){
        myBookerPage.clickMyAccountLink();
    }

    @QAFTestStep(description="I choose an option scanner from the header list Ordering Tools by mouse hovering")
    public void iChooseAnOptionScannerFromTheHeaderListOrderingToolsByMouseHovering(){
        myBookerPage.selectingScannerOptionFromOrderingToolsUsingMouseHover();
    }

}
