package com.quantum.pages;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.PropertyUtil;

import java.util.Map;


public class PaymentPage extends WebDriverBaseTestPage<WebDriverTestPage> {
    @Override
    protected void openPage(PageLocator locator, Object... args) {
    }
    PropertyUtil props = ConfigurationManager.getBundle();

    @FindBy(locator = "#cardNumber")
    private QAFExtendedWebElement cardNumber;

    @FindBy(locator = "#cardholderName")
    private QAFExtendedWebElement cardholderName;

    @FindBy(locator = "#expiryMonth")
    private QAFExtendedWebElement expiryMonth;

    @FindBy(locator = "#expiryYear")
    private QAFExtendedWebElement expiryYear;

    @FindBy(locator = "#securityCode")
    private QAFExtendedWebElement securityCode;

    @FindBy(locator = "#submitButton")
    private QAFExtendedWebElement  submitButton;


    public void submitPaymentDetails(String cNumber, String cName, String eMonth, String eYear, String csv) throws InterruptedException {
        driver.switchTo().frame(0);
        Thread.sleep(10000);
        cardNumber.waitForVisible(60000);
        cardNumber.sendKeys(cNumber);
        cardholderName.sendKeys(cName);
        expiryMonth.sendKeys(eMonth);
        expiryYear.sendKeys(eYear);
        securityCode.sendKeys(csv);
        Thread.sleep(2000);
        submitButton.waitForVisible(5000);
        submitButton.click();
        driver.switchTo().defaultContent();
    }
}
