package com.quantum.pages.registrationPages;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.PropertyUtil;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.Select;

public class WhatIsYourBusinessPage extends WebDriverBaseTestPage<WebDriverTestPage> {

    PropertyUtil props = ConfigurationManager.getBundle();

    @Override
    protected void openPage(PageLocator locator, Object... args) {
    }

    @FindBy(locator = "reg.what.is.your.business.inputBox")
    QAFExtendedWebElement yourBusinessInputBox;

    @FindBy(locator = "dropdown.autoComplete.list")
    QAFExtendedWebElement dropdownlist;

    @FindBy(locator = "dropdown.option.night.club")
    QAFExtendedWebElement optionNightClub;

    @FindBy(locator = "create.your.business.button")
    QAFExtendedWebElement createYourBusinessButton;


    public void selectYourBusiness(String yourBusinessEntered) throws InterruptedException {
        //Entering values into input box
        yourBusinessInputBox.waitForVisible(5000);
        yourBusinessInputBox.clear();
        yourBusinessInputBox.sendKeys(yourBusinessEntered);

        //wait.until expected condition here
        dropdownlist.waitForVisible(5000);
        //selecting the value from the listed dropdown
        optionNightClub.click();
    }

    public void clickCreateYourBusinessButton() throws InterruptedException {
        createYourBusinessButton.waitForVisible(1000);
        createYourBusinessButton.click();
    }







}
