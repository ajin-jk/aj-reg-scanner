package com.quantum.steps;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.quantum.utils.ReportUtils;

public class AdditionalInformationPageSteps extends AbstractSteps {

    @QAFTestStep(description="I click on proceed button on additional information page")
    public void iClickOnProceedButtonOnAdditionalInformationPage(){
        additionalInformationPage.clickProceedToCheckoutButton();
    }

    @QAFTestStep(description="I choose a available slot from the choose a collection slot page")
    public void iChooseAAvailableSlotFromTheChooseACollectionSlotPage(){
        additionalInformationPage.chooseACollectionSlot();
    }

    @QAFTestStep(description="I click on proceed button on additional information page for clickNCollect customer")
    public void iClickOnProceedButtonOnAdditionalInformationPageForClickNCollectCustomer(){
        additionalInformationPage.clickProceedToCheckoutButtonForClickNCollectCustomer();
    }

}
